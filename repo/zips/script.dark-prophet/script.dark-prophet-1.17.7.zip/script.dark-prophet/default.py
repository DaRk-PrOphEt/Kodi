# -*- coding: utf-8 -*-
import contextlib
import errno
import glob
import html
import json
import os
import random
import re
import shutil
import sqlite3
import stat
import struct
import sys
import threading
import time
import zlib
import zipfile
from http.client import HTTPException
from http.server import BaseHTTPRequestHandler, HTTPServer
from io import BytesIO
from urllib.error import HTTPError, URLError
from urllib.parse import parse_qs, quote
from urllib.request import urlopen
from xml.etree import ElementTree

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

TITRE = 'DaRk-PrOphEt'
SKIN = 'skin.arctic.fuse.3'
SKIN_ESTUARY = 'skin.estuary'   # habillage d'origine de Kodi : version Extra-Light
SKIN_SECOURS = 'skin.estuary'
ALKOFLIX = 'plugin.video.alkoflix'
CATCHUP = 'plugin.video.catchuptvandmore'
VSTREAM = 'plugin.video.vstream'   # version « Full » seulement : le secours quand alkoFlix n'a pas de lien
LANGUE = 'resource.language.fr_fr'
SONS = 'resource.uisounds.androidtv'
# Icônes des menus d'alkoFlix : les packs de réglages s'en servent, mais
# alkoFlix ne les installe pas d'office (dépendance facultative).
ICONES = 'resource.images.alkodicons.coal'
# Suggestions du clavier : sans elle, Arctic Fuse 3 propose de l'installer à
# chaque ouverture du clavier.
SAISIE = 'plugin.program.autocompletion'
# Les replays en ont besoin, les bandes-annonces passent par YouTube : installés
# d'avance, Kodi ne les réclame plus au premier replay ni à la première bande-annonce.
FLUX = 'inputstream.adaptive'
YOUTUBE = 'plugin.video.youtube'
# « Épisode suivant » à la fin d'un épisode : alkoFlix s'en sert d'office, mais ne l'installe pas.
UPNEXT = 'service.upnext'
# Version « Full » seulement : un bouton « Passer l'intro / le résumé / le générique »
# pendant la lecture, quand l'épisode est connu de la base communautaire TheIntroDB.
INTRO = 'plugin.video.tidb'
# Version « Full » seulement : vStream s'en sert pour joindre les sites que les fournisseurs
# d'accès bloquent par DNS (recherches vides sinon). Publié en zip sur la page de vStream,
# hors de tout dépôt : notre dépôt le sert tel quel.
DNS = 'script.module.dnspython'
TMDBHELPER = 'plugin.video.themoviedb.helper'
LECTEUR = 'alkoflix.select.json'
GUIDS_MENU_OPTIONS = ('guid-022adae1', 'guid-549c9ded', 'guid-dpscript', 'guid-dpextensions', 'guid-dpcatchup', 'guid-dpalkoflix')   # Favoris, Gestionnaire des fichiers et nos anciennes lignes
ICONE_SCRIPT = 'screwdriver-wrench.png'   # icône d'Arctic Fuse 3 pour le raccourci du menu Options
NOMS = {SKIN: 'Arctic Fuse 3', ALKOFLIX: 'alkoFlix', CATCHUP: 'Catch-up TV & More',
        LANGUE: 'la langue française', SONS: 'les sons Android TV', ICONES: "les icônes d'alkoFlix",
        SAISIE: 'les suggestions du clavier', FLUX: 'la lecture des replays (InputStream Adaptive)',
        YOUTUBE: 'YouTube (bandes-annonces)', UPNEXT: "Up Next (l'épisode suivant)"}
# Dépôt officiel de chaque extension. Le script les installe lui-même : Kodi
# refuse d'installer un dépôt en tant que dépendance d'une autre extension.
DEPOTS = {SKIN: 'repository.jurialmunkey', ALKOFLIX: 'repository.alkoflix', CATCHUP: 'catchuptvandmore.kodi.release',
          VSTREAM: 'repository.vstream', INTRO: 'repository.tidb.repo'}
NOMS.update({VSTREAM: 'vStream', 'repository.vstream': 'le dépôt de vStream'})
NOMS.update({DNS: 'DNS Python (sites bloqués par le fournisseur)'})
NOMS.update({INTRO: "TheIntroDB (passer l'intro)", 'repository.tidb.repo': 'le dépôt de TheIntroDB'})
NOMS.update({'repository.jurialmunkey': "le dépôt d'Arctic Fuse 3", 'repository.alkoflix': "le dépôt d'alkoFlix",
             'catchuptvandmore.kodi.release': 'le dépôt de Catch-up TV'})
# Le confort : si l'un d'eux ne s'installe pas, la formule continue quand même.
FACULTATIFS = (LANGUE, SONS, ICONES, SAISIE, FLUX, YOUTUBE, UPNEXT, INTRO, DNS, 'repository.tidb.repo')

PACKS_URL = 'https://raw.githubusercontent.com/DaRk-PrOphEt/Kodi/main/packs/'
PACK_ALKOFLIX = 'arctic-fuse-3.zip'
# Même interface avec moins de rangées par page, pour les boîtiers modestes.
PACK_LEGER = 'arctic-fuse-3-leger.zip'
PACK_CATCHUP = 'arctic-fuse-3-catchup.zip'
# Limites d'un pack : les vrais font environ 12 Ko compressés, 45 Ko décompressés, 14 fichiers.
# Large marge, mais un fichier détourné ne peut pas saturer la mémoire ni le stockage d'un boîtier modeste.
PACK_MAX_TELECHARGE = 5 * 1024 * 1024   # octets reçus
PACK_MAX_ENTREE = 5 * 1024 * 1024       # un fichier décompressé
PACK_MAX_TOTAL = 20 * 1024 * 1024       # tous les fichiers décompressés
PACK_MAX_ENTREES = 500

# Les deux entrées de l'écran de choix au démarrage (formule alkoFlix + Catch-up TV).
PROFIL_ALKOFLIX = 'alkoFlix'
PROFIL_CATCHUP = 'Catch-up TV'

# Seuls ces dossiers de réglages voyagent dans un pack : la mise en page,
# jamais les réglages d'extensions qui contiennent des identifiants.
DOSSIERS = (SKIN, 'script.skinvariables')

# Comptes que Catch-up TV & More sait utiliser (préfixe de ses réglages).
COMPTES = (
    ('TF1+', 'tf1plus'),
    ('M6+ (6play)', '6play'),
    ('RMC BFM Play', 'rmcbfmplay'),
    ('SFR TV', 'sfrtv'),
    ('ABweb', 'abweb'),
)

MAITRE = xbmcvfs.translatePath('special://masterprofile/')
PROFIL = xbmcvfs.translatePath('special://profile/')
ADDON_DATA = os.path.join(PROFIL, 'addon_data')
SAUVEGARDE = os.path.join(ADDON_DATA, 'script.dark-prophet', 'sauvegarde')
# Place à garder libre en plus de ce qu'on écrit : Kodi doit pouvoir enregistrer ses propres fichiers.
MARGE_PLACE = 5 * 1024 * 1024
# Jusqu'à la 1.14, le propriétaire du dépôt pouvait saisir un jeton GitHub pour
# publier un pack depuis Kodi. La fonction est retirée ; on efface ce qu'elle
# a pu laisser sur l'appareil (le jeton y était en clair).
RESTES_JETON = (os.path.join(MAITRE, 'addon_data', 'script.dark-prophet', 'jeton'),
                os.path.join(MAITRE, 'addon_data', 'script.dark-prophet', 'settings.xml'),
                os.path.join(ADDON_DATA, 'script.dark-prophet', 'settings.xml'))
# Interface choisie à l'installation (« complet » ou « leger »), pour que la
# mise à jour ne repose pas la question.
FICHIER_INTERFACE = os.path.join(MAITRE, 'addon_data', 'script.dark-prophet', 'interface')

# Fonds d'écran proposés pour le profil alkoFlix (une image fixe : aucun effet sur la fluidité).
FONDS = (('Rouge', 'alkoflix-rouge.jpg'), ('Bleu', 'alkoflix-bleu.jpg'))
FICHIER_FOND = os.path.join(MAITRE, 'addon_data', 'script.dark-prophet', 'fond')
# Lumio (source externe d'alkoFlix) a été proposé de la 1.16.0 à la 1.16.4, puis retiré :
# ses fichiers, et le témoin qui évite de refaire le ménage (voir retirer_lumio).
FICHIER_LUMIO = os.path.join(MAITRE, 'addon_data', 'script.dark-prophet', 'lumio_pause')
FICHIER_LUMIO_AVANT = os.path.join(MAITRE, 'addon_data', 'script.dark-prophet', 'lumio_sources_avant.json')
FICHIER_LUMIO_RETIRE = os.path.join(MAITRE, 'addon_data', 'script.dark-prophet', 'lumio_retire')
DOSSIER_FONDS = os.path.join(MAITRE, 'addon_data', 'script.dark-prophet')
FOND_HABILLAGE = 'special://skin/extras/backgrounds/blur/purple_blur.jpg'   # celui des packs
FOND_CATCHUP = 'catchup.jpg'   # l'image officielle de Catch-up TV & More, assombrie

# Image de la case « Plus… » en bout de rangée. Arctic Fuse 3 la lit dans son fichier
# groupé Textures.xbt, qui passe avant tout fichier posé dans son dossier : on fait donc
# pointer la seule ligne de l'habillage qui la cite vers notre image. Une mise à jour de
# l'habillage remet sa ligne ; service.py la repointe au démarrage suivant.
IMAGE_PLUS = 'more-items-wide.png'
DOSSIER_IMAGES = os.path.join(MAITRE, 'addon_data', 'script.dark-prophet', 'images')
PLUS_ORIGINE = '>fallback/more-items-wide.png<'
PLUS_REMPLACEE = '>special://masterprofile/addon_data/script.dark-prophet/images/more-items-wide.png<'

# Image de chaque profil sur l'écran de choix : l'icône officielle de son extension.
LOGOS = {PROFIL_ALKOFLIX: 'special://home/addons/%s/icon.png' % ALKOFLIX,
         PROFIL_CATCHUP: 'special://home/addons/%s/icon.png' % CATCHUP}
FICHIER_PROFILS = os.path.join(MAITRE, 'profiles.xml')
# Tant que ce fichier existe, profiles.xml est protégé en écriture (voir poser_logos).
VERROU_PROFILS = os.path.join(MAITRE, 'addon_data', 'script.dark-prophet', 'profils_verrouilles')
# Dossiers de profils à effacer une fois Kodi redémarré (voir reinitialiser).
PROFILS_A_EFFACER = os.path.join(MAITRE, 'addon_data', 'script.dark-prophet', 'profils_a_effacer')
# Réglages de Kodi relevés avant la première installation, pour pouvoir les remettre.
ETAT_AVANT = os.path.join(MAITRE, 'addon_data', 'script.dark-prophet', 'etat_avant.json')
REGLAGES_KODI = ('lookandfeel.skin', 'lookandfeel.soundskin', 'locale.keyboardlayouts', 'locale.country',
                 'addons.updatemode', 'locale.audiolanguage', 'videoplayer.preferdefaultflag',
                 'locale.subtitlelanguage', 'subtitles.languages', 'filelists.showparentdiritems', 'videoscreen.limitgui',
                 'myvideos.selectaction', 'myvideos.playaction',
                 'locale.language')   # la langue en dernier : Kodi recharge tout

# Touche Retour pendant un film : arrête la lecture (d'origine, elle revient aux
# menus en laissant le film tourner derrière). Avec les commandes à l'écran
# ouvertes, Retour ne fait que les refermer.
REPRENDRE = 2   # valeur de « Reprendre » dans les réglages Vidéos de Kodi
NOM_TOUCHES = 'dark-prophet.xml'
TOUCHES = """<?xml version="1.0" encoding="UTF-8"?>
<keymap>
    <FullscreenVideo>
        <keyboard>
            <backspace>Stop</backspace>
        </keyboard>
        <remote>
            <back>Stop</back>
        </remote>
    </FullscreenVideo>
</keymap>
"""
# Réglages posés dans les extensions de confort. YouTube : pas d'assistant de
# configuration à la première bande-annonce ; sans MPEG-DASH et en 1080p/720p au plus,
# les bandes-annonces ne se figent plus au bout de quelques secondes.
REGLAGES_EXTENSIONS = {
    SAISIE: {'autocomplete_lang': 'fr'},
    YOUTUBE: {'kodion.setup_wizard': 'false', 'kodion.setup_wizard.forced_runs': '2147483647',
              'kodion.mpd.videos': 'false', 'kodion.video.quality': '4'},
    # L'épisode suivant s'enchaîne aussi dans une liste de lecture et sur une série déjà vue.
    UPNEXT: {'enablePlaylist': 'true', 'includeWatched': 'true'},
    # Conseil des auteurs d'alkoFlix : sans ce réglage, la lecture lancée depuis une fiche
    # de l'habillage peut faire planter Kodi sur certains appareils.
    TMDBHELPER: {'only_resolve_strm': 'true'},
    # TheIntroDB : pas de statistiques d'utilisation envoyées.
    INTRO: {'anonymous_usage_reporting': 'false'},
    # « Info & Extra » ouvre la fenêtre d'information d'Arctic Fuse 3 (la même que la touche
    # Info) au lieu de celle d'alkoFlix : même allure partout, et les notes par épisode.
    # Recherche de liens plus courte, repris des réglages officiels d'alkoFlix sans toucher
    # à la qualité (la 4K reste proposée) : on n'attend plus la source la plus lente, et
    # moins de liens à trier = un écran de liens qui s'affiche plus vite.
    ALKOFLIX: {'info_extra.window': 'false', 'search.finish.early': 'true',
               'results.max_total': '15', 'results.max_per_resolution': '6'},
}

# Là où Catch-up TV et alkoFlix rangent les favoris, la liste à voir et les
# lectures en cours du profil ouvert : quand l'un de ces fichiers change, les
# rangées de l'accueil sont à recharger.
TEMOINS_LISTES = (os.path.join(ADDON_DATA, CATCHUP, 'favourites.json'),
                  os.path.join(ADDON_DATA, ALKOFLIX, 'favourites.db'),
                  os.path.join(ADDON_DATA, ALKOFLIX, 'watched.db'))

# Écran « Profils » de Kodi : identifiants fixés par Kodi, les mêmes dans tous les habillages.
LISTE_PROFILS = 2
BOUTON_ECRAN_CHOIX = 4
BOUTON_OK_DOSSIER = 413
BOUTON_OK_REGLAGES = 28
BOUTON_OUI = 11
BOUTON_NON = 10

dialog = xbmcgui.Dialog()


def log(msg):
    xbmc.log('[script.dark-prophet] %s' % msg, xbmc.LOGINFO)


def rpc(methode, params=None):
    reponse = xbmc.executeJSONRPC(json.dumps({'jsonrpc': '2.0', 'id': 1, 'method': methode, 'params': params or {}}))
    return json.loads(reponse).get('result')


def attendre(condition, secondes):
    """Attend qu'une condition Kodi devienne vraie. Renvoie False si le délai est dépassé."""
    moniteur = xbmc.Monitor()
    for _ in range(secondes * 4):
        if xbmc.getCondVisibility(condition):
            return True
        if moniteur.waitForAbort(0.25):
            return False
    return xbmc.getCondVisibility(condition)


def annoncer(texte):
    """Message de fin. Arctic Fuse 3 recharge l'habillage quand ses réglages
    changent, ce qui referme le message sans qu'on l'ait lu : on le réaffiche."""
    for _ in range(3):
        if dialog.ok(TITRE, texte):
            return
        xbmc.sleep(3000)


def installe(addon_id):
    return xbmc.getCondVisibility('System.HasAddon(%s)' % addon_id)


def dans_le_profil_principal():
    return os.path.normpath(PROFIL) == os.path.normpath(MAITRE)


# --- Installation des extensions -------------------------------------------

def rafraichir_depots():
    # Les dépôts tiers viennent d'être installés avec ce script : Kodi doit
    # avoir lu leur catalogue avant de pouvoir y trouver quoi que ce soit.
    xbmc.executebuiltin('UpdateAddonRepos')
    xbmc.sleep(8000)


def installer_extension(addon_id):
    """Lance l'installation, confirme à la place de l'utilisateur et attend qu'elle aboutisse."""
    if installe(addon_id):
        return True
    # Livrée avec Kodi mais éteinte (InputStream Adaptive sur certains appareils) : on l'allume.
    rpc('Addons.SetAddonEnabled', {'addonid': addon_id, 'enabled': True})
    if attendre('System.HasAddon(%s)' % addon_id, 2):
        return True
    xbmc.executebuiltin('InstallAddon(%s)' % addon_id)
    if attendre('Window.IsVisible(yesnodialog)', 15):
        xbmc.executebuiltin('SendClick(%d)' % BOUTON_OUI)
    moniteur = xbmc.Monitor()
    for _ in range(600):
        if installe(addon_id):
            break
        if xbmc.getCondVisibility('Window.IsVisible(okdialog)'):
            # Kodi annonce un échec (dépendance introuvable, téléchargement coupé…).
            xbmc.executebuiltin('Dialog.Close(okdialog)')
            return False
        if moniteur.waitForAbort(0.5):
            return False
    else:
        return False
    # Les dépendances finissent de s'installer juste après.
    xbmc.sleep(5000)
    if addon_id in (SKIN, LANGUE) and attendre('Window.IsVisible(yesnodialog)', 5):
        # Kodi propose de basculer tout de suite : non, le script s'en charge au bon moment.
        xbmc.executebuiltin('SendClick(%d)' % BOUTON_NON)
        xbmc.sleep(1000)
    return True


def installer_tout(addon_ids):
    """Installe ce qui manque. Renvoie False (après l'avoir dit) au premier échec."""
    manquants = []
    for addon_id in addon_ids:
        if not installe(addon_id):
            depot = DEPOTS.get(addon_id)
            if depot and not installe(depot):
                manquants.append(depot)
            manquants.append(addon_id)
    if not manquants:
        return True
    # Arctic Fuse 3 demande des versions de ses dépendances plus récentes que
    # celles du dépôt officiel de Kodi : sans ce réglage (« Mettre à jour les
    # extensions officielles depuis : Tous les dépôts »), Kodi refuse de l'installer.
    rpc('Settings.SetSettingValue', {'setting': 'addons.updatemode', 'value': 1})
    progression = xbmcgui.DialogProgressBG()
    progression.create(TITRE, 'Lecture des dépôts…')
    try:
        rafraichir_depots()
        for numero, addon_id in enumerate(manquants):
            progression.update(int(100 * numero / len(manquants)), TITRE, 'Installation de %s…' % NOMS[addon_id])
            if numero and manquants[numero - 1] in DEPOTS.values():
                # Un dépôt vient d'arriver : Kodi doit lire son catalogue.
                rafraichir_depots()
            # Sur un Kodi tout neuf, les catalogues des dépôts arrivent parfois
            # après la première tentative : on réessaie une fois.
            if not installer_extension(addon_id) and not (rafraichir_depots() or installer_extension(addon_id)):
                if addon_id in FACULTATIFS:
                    log('%s non installé, on continue' % addon_id)
                    continue
                if addon_id == SKIN:
                    dialog.ok(TITRE, "Arctic Fuse 3 n'a pas pu être installé.[CR]Son dépôt ne propose peut-être pas de version "
                                     "pour ce Kodi (Kodi 21 « Omega » conseillé), ou la connexion a coupé. L'habillage actuel n'a pas changé.")
                else:
                    dialog.ok(TITRE, "%s n'a pas pu être installé.[CR]Vérifie la connexion et que Kodi est en version 21 ou plus, puis relance." % NOMS[addon_id])
                return False
    finally:
        progression.close()
    return True


def regler(reglage, valeur):
    """Change un réglage de Kodi s'il n'a pas déjà cette valeur. Renvoie True s'il a changé."""
    if (rpc('Settings.GetSettingValue', {'setting': reglage}) or {}).get('value') == valeur:
        return False
    rpc('Settings.SetSettingValue', {'setting': reglage, 'value': valeur})
    return True


def franciser():
    """Kodi en français (langue, formats de date et d'heure, clavier AZERTY, audio et
    sous-titres à la lecture) avec les sons d'Android TV."""
    if installe(LANGUE) and regler('locale.language', LANGUE):
        # Kodi recharge ses textes et l'habillage.
        xbmc.sleep(4000)
        regler('locale.country', 'France')
        xbmc.sleep(1000)
    regler('locale.keyboardlayouts', ['French AZERTY'])
    # Lecture : la piste audio française plutôt que celle marquée « par défaut » dans le
    # fichier (souvent l'anglais), et seulement les sous-titres forcés (passages en langue
    # étrangère), pas des sous-titres complets.
    regler('locale.audiolanguage', 'French')
    regler('videoplayer.preferdefaultflag', False)
    regler('locale.subtitlelanguage', 'forced_only')
    regler('subtitles.languages', ['French'])
    if installe(SONS):
        regler('lookandfeel.soundskin', SONS)


def ecrire_reglages(fichier, valeurs):
    """Pose des réglages dans un fichier de réglages de Kodi (guisettings.xml ou
    settings.xml d'une extension) d'un profil qui n'est PAS ouvert."""
    try:
        arbre = ElementTree.parse(fichier)
    except (OSError, ElementTree.ParseError):
        arbre = ElementTree.ElementTree(ElementTree.fromstring('<settings version="2" />'))
    racine = arbre.getroot()
    for cle, valeur in valeurs.items():
        for reglage in racine.iter('setting'):
            if reglage.get('id') == cle:
                reglage.text = valeur
                reglage.attrib.pop('default', None)
                break
        else:
            ElementTree.SubElement(racine, 'setting', id=cle).text = valeur
    os.makedirs(os.path.dirname(fichier), exist_ok=True)
    arbre.write(fichier, encoding='utf-8')


def poser_touches(dossier):
    cible = os.path.join(dossier, 'keymaps', NOM_TOUCHES)
    os.makedirs(os.path.dirname(cible), exist_ok=True)
    with open(cible, 'w', encoding='utf-8') as sortie:
        sortie.write(TOUCHES)


def regler_confort(autre_profil=None):
    """Les petits réglages qui évitent des questions et des gestes : pas de
    ligne « .. » en tête des listes, une seule question « reprendre ? »,
    interface en 1080p sur Android, Retour arrête le film, suggestions du
    clavier en français, YouTube sans assistant, épisode suivant enchaîné.
    autre_profil : dossier d'un profil fermé à régler de la même façon."""
    regler('filelists.showparentdiritems', False)
    # « Reprendre » aux deux endroits : Kodi ne demande plus « lire ou reprendre ? » sur
    # l'affiche puis de nouveau sur le lien, alkoFlix pose la question une seule fois.
    regler('myvideos.selectaction', REPRENDRE)
    regler('myvideos.playaction', REPRENDRE)
    # Android seulement : l'interface plafonnée à 1080p. Sur un boîtier 4K, dessiner les
    # menus en 4K alourdit Arctic Fuse 3 pour un gain invisible à la télé ; les films,
    # eux, restent en 4K. Ailleurs le réglage n'existe pas et la commande est sans effet.
    regler('videoscreen.limitgui', 1080)
    for addon_id, valeurs in REGLAGES_EXTENSIONS.items():
        if not installe(addon_id):
            continue
        try:
            extension = xbmcaddon.Addon(addon_id)
            for cle, valeur in valeurs.items():
                extension.setSetting(cle, valeur)
        except RuntimeError as erreur:
            log('réglages de %s : %r' % (addon_id, erreur))
        if autre_profil:
            ecrire_reglages(os.path.join(autre_profil, 'addon_data', addon_id, 'settings.xml'), valeurs)
    try:
        poser_touches(PROFIL)
        if autre_profil:
            poser_touches(autre_profil)
            reglages = {'filelists.showparentdiritems': 'false', 'myvideos.selectaction': str(REPRENDRE),
                        'myvideos.playaction': str(REPRENDRE)}
            if xbmc.getCondVisibility('System.Platform.Android'):
                reglages['videoscreen.limitgui'] = '1080'
            ecrire_reglages(os.path.join(autre_profil, 'guisettings.xml'), reglages)
        xbmc.executebuiltin('Action(reloadkeymaps)')
    except OSError as erreur:
        log('touches : %r' % erreur)


# --- Habillage et packs de réglages ----------------------------------------

def changer_habillage(skin):
    if xbmc.getSkinDir() == skin:
        return True
    rpc('Settings.SetSettingValue', {'setting': 'lookandfeel.skin', 'value': skin})
    # Kodi demande « Conserver ce changement ? » et annule seul au bout de
    # quelques secondes : on répond Oui à sa place.
    if attendre('Window.IsVisible(yesnodialog)', 20):
        xbmc.executebuiltin('SendClick(%d)' % BOUTON_OUI)
    moniteur = xbmc.Monitor()
    for _ in range(40):
        if xbmc.getSkinDir() == skin:
            xbmc.sleep(2000)
            return True
        if moniteur.waitForAbort(0.5):
            return False
    return False


def verifier_pack(archive):
    """Contrôle un pack AVANT toute écriture sur l'appareil. Renvoie None s'il est
    utilisable, sinon la raison du refus. Lève zipfile.BadZipFile si une entrée est corrompue."""
    entrees = archive.infolist()
    if not entrees:
        return 'archive vide'
    if len(entrees) > PACK_MAX_ENTREES:
        return 'trop de fichiers (%d)' % len(entrees)
    total, vus, fichiers = 0, set(), set()
    for info in entrees:
        morceaux = morceaux_surs(info.filename)
        if morceaux is None:
            return 'chemin dangereux : %r' % info.filename
        if est_un_lien(info):
            return 'lien symbolique : %s' % info.filename
        # Deux entrées au même endroit (la casse ne compte pas sur Windows et en FAT) : ambigu.
        cle = '/'.join(morceaux).lower()
        if cle in vus:
            return 'entrée en double : %s' % info.filename
        vus.add(cle)
        if not info.is_dir():
            fichiers.add(cle)
        if info.file_size > PACK_MAX_ENTREE:
            return '%s est trop gros (%d octets)' % (info.filename, info.file_size)
        total += info.file_size
    if total > PACK_MAX_TOTAL:
        return 'contenu trop gros (%d octets)' % total
    for cle in vus:   # un fichier ne peut pas servir aussi de dossier à une autre entrée
        morceaux = cle.split('/')
        if any('/'.join(morceaux[:i]) in fichiers for i in range(1, len(morceaux))):
            return 'fichier et dossier au même nom : %s' % cle
    membres = {info.filename.replace('\\', '/'): info for info, _ in membres_autorises(archive, ADDON_DATA)}
    essentiel = 'addon_data/%s/settings.xml' % SKIN
    if essentiel not in membres:
        return 'réglages de l\'habillage absents'
    # Tailles déjà bornées : la lecture complète (CRC compris) ne peut plus saturer la mémoire.
    try:
        mauvais = archive.testzip()
    except (zlib.error, NotImplementedError, RuntimeError, EOFError) as erreur:
        raise zipfile.BadZipFile('lecture impossible : %r' % erreur)
    if mauvais:
        raise zipfile.BadZipFile('entrée corrompue : %s' % mauvais)
    for nom, info in membres.items():
        try:
            if nom == essentiel:
                if ElementTree.fromstring(archive.read(info)).tag != 'settings':
                    return '%s : racine inattendue' % nom
            elif nom.endswith('.json'):
                json.loads(archive.read(info))
        except (ElementTree.ParseError, ValueError):
            return '%s : contenu illisible' % nom
    return None


def telecharger_pack(nom, muet=False):
    """Renvoie l'archive vérifiée, ou None (pack pas encore publié, réseau en panne,
    pack inutilisable). Rien n'est écrit sur l'appareil ici."""
    try:
        with urlopen(PACKS_URL + nom, timeout=30) as reponse:
            donnees = reponse.read(PACK_MAX_TELECHARGE + 1)
        if len(donnees) > PACK_MAX_TELECHARGE:
            log('pack %s trop gros, refusé' % nom)
            return None
        archive = zipfile.ZipFile(BytesIO(donnees))
        raison = verifier_pack(archive)
        if raison is None:
            return archive
        log('pack %s refusé : %s' % (nom, raison))
    except HTTPError as erreur:
        log('pack %s : erreur %s' % (nom, erreur.code))
        if not muet and erreur.code != 404:
            dialog.ok(TITRE, 'Téléchargement refusé (erreur %s).' % erreur.code)
    except (URLError, OSError, HTTPException, zipfile.BadZipFile) as erreur:
        log('pack %s : %r' % (nom, erreur))
        if not muet:
            dialog.ok(TITRE, 'Téléchargement impossible. Vérifie la connexion puis relance.')
    return None


VERSIONS = (('extra', "Extra-Light : habillage d'origine de Kodi, le plus léger"),
            ('leger', 'Allégée : pour les boîtiers modestes'),
            ('complet', 'Base : interface complète'),
            ('full', "Full : Base + vStream + bouton « Passer l'intro »"))


def choisir_version(redemander=True, avec_extra=True):
    """Version à installer sur le profil alkoFlix : « extra » (Estuary), « leger »,
    « complet » (la Base) ou « full ». Le choix est retenu : avec redemander=False,
    on le reprend sans reposer la question ; sinon la question part du choix
    retenu. avec_extra=False : pour ce qui repose sur Arctic Fuse 3 (profil
    Catch-up TV, mise à jour de l'interface), l'Extra-Light n'est pas proposée."""
    choix = ''
    if os.path.isfile(FICHIER_INTERFACE):
        choix = open(FICHIER_INTERFACE).read().strip()
    versions = [v for v in VERSIONS if avec_extra or v[0] != 'extra']
    cles = [cle for cle, _ in versions]
    if redemander or choix not in cles:
        numero = dialog.select('Quelle version ?', [libelle for _, libelle in versions],
                               preselect=cles.index(choix) if choix in cles else cles.index('complet'))
        if numero < 0:
            return None   # « Annuler » : on ne fait rien
        choix = versions[numero][0]
        os.makedirs(os.path.dirname(FICHIER_INTERFACE), exist_ok=True)
        with open(FICHIER_INTERFACE, 'w') as sortie:
            sortie.write(choix)
    return choix


def telecharger_pack_alkoflix(version):
    """Le pack du profil alkoFlix. La Full utilise celui de la Base : le
    script y ajoute ce qui concerne vStream."""
    if version == 'leger':
        leger = telecharger_pack(PACK_LEGER, muet=True)
        if leger is not None:
            return leger
    return telecharger_pack(PACK_ALKOFLIX)


# Interdits dans un nom de fichier sous Windows (et sur les cartes en FAT/exFAT).
CARACTERES_INTERDITS = set('<>:"|?*')
NOMS_RESERVES = {'CON', 'PRN', 'AUX', 'NUL'} | {'%s%d' % (n, i) for n in ('COM', 'LPT') for i in range(1, 10)}


def morceaux_surs(nom):
    """Découpe le chemin d'une entrée de zip. None s'il est dangereux ou impossible à
    écrire sur certains appareils : absolu, « . » ou « .. », morceau vide, caractère de
    contrôle ou interdit par Windows, nom réservé (CON, NUL…), point ou espace final."""
    nom = nom.replace('\\', '/')
    if nom.startswith('/'):
        return None
    morceaux = nom[:-1].split('/') if nom.endswith('/') else nom.split('/')   # « / » final : un dossier
    for morceau in morceaux:
        if (morceau in ('', '.', '..') or morceau != morceau.rstrip('. ')
                or any(c in CARACTERES_INTERDITS or ord(c) < 32 for c in morceau)
                or morceau.split('.')[0].upper() in NOMS_RESERVES):
            return None
    return morceaux


def est_un_lien(info):
    return stat.S_ISLNK(info.external_attr >> 16)


def membres_autorises(archive, racine):
    """Fichiers du pack qu'on accepte d'écrire : addon_data/<dossier connu>/...
    Mêmes règles de chemin que verifier_pack (morceaux_surs)."""
    for info in archive.infolist():
        morceaux = morceaux_surs(info.filename)
        if info.is_dir() or est_un_lien(info) or not morceaux or len(morceaux) < 3:
            continue
        if morceaux[0] != 'addon_data' or morceaux[1] not in DOSSIERS:
            continue
        yield info, os.path.join(racine, *morceaux[1:])


# --- Remplacement sûr des réglages d'habillage ----------------------------------
# Les dossiers DOSSIERS d'un profil ne sont jamais vidés avant que leur remplaçant soit
# complet. Tout se passe dans <addon_data>/script.dark-prophet/transaction (même stockage
# que les réglages, donc des renommages simples) :
#   1. « preparation » : le nouveau contenu est écrit dans transaction/nouveau, puis contrôlé ;
#   2. « bascule » (noté sur disque) : chaque dossier actuel part dans transaction/ancien,
#      le nouveau prend sa place ;
#   3. le dossier de transaction est effacé.
# Après une coupure : en « preparation », rien n'avait été touché, on jette la préparation ;
# en « bascule », le nouveau contenu est complet et vérifié : on termine la bascule ;
# en « annulation » (échec pendant la bascule), on termine le retour aux anciens réglages ;
# en « terminee », il ne reste qu'à effacer le dossier de transaction.
# Un verrou par profil empêche deux lancements de toucher en même temps aux mêmes fichiers.

class PackNonApplique(Exception):
    """Les réglages n'ont pas été remplacés : ceux d'avant sont intacts (le message le dit)."""


def cause(erreur):
    if getattr(erreur, 'errno', None) == errno.ENOSPC:
        return 'stockage plein'
    if getattr(erreur, 'errno', None) == errno.EXDEV:
        return 'dossiers sur des stockages différents'
    return getattr(erreur, 'strerror', None) or str(erreur)


def place_libre(chemin):
    """Octets disponibles là où `chemin` sera écrit, ou None si l'appareil ne le dit pas."""
    while not os.path.isdir(chemin) and os.path.dirname(chemin) != chemin:
        chemin = os.path.dirname(chemin)
    try:
        return shutil.disk_usage(chemin).free
    except (OSError, ValueError):
        return None


# Place prise par Arctic Fuse 3 et ses extensions sur un Kodi neuf, ZIP compris (Kodi garde chaque
# ZIP dans addons/packages) : mesuré le 17/11/2026 sur Kodi 21.3, 909 Mo en Base, 930 Mo en Full.
BESOIN_ARCTIC = 950 * 1000 * 1000


def place_manquante_arctic():
    """Mo libres si l'appareil n'a manifestement pas la place d'installer Arctic Fuse 3, sinon
    None (déjà installé, place suffisante, ou espace libre inconnu : on n'empêche rien)."""
    if installe(SKIN):
        return None
    libre = place_libre(xbmcvfs.translatePath('special://home/addons/'))
    if libre is None or libre >= BESOIN_ARCTIC:
        return None
    return libre // (1000 * 1000)


def verifier_place(chemin, octets):
    """Refuse AVANT toute écriture s'il manque de la place. Si l'appareil ne donne pas
    l'espace libre, on continue : rien n'est supprimé avant que la copie soit complète,
    un stockage plein ne fait qu'interrompre la préparation."""
    libre, besoin = place_libre(chemin), octets + MARGE_PLACE
    if libre is None:
        log('espace libre inconnu pour %s : on continue' % chemin)
    elif libre < besoin:
        raise PackNonApplique("Pas assez de place sur l'appareil (il faut environ %d Mo de libre).[CR]"
                              "Tes réglages actuels n'ont pas été modifiés. Lance « Nettoyer Kodi » puis réessaie."
                              % (besoin // 1048576 + 1))


def inventaire(dossier):
    """{chemin relatif : taille} des fichiers sous `dossier` ({} s'il n'existe pas).
    Lève OSError si un sous-dossier est illisible, au lieu de l'ignorer."""
    if not os.path.isdir(dossier):
        return {}
    contenu = {}

    def illisible(erreur):
        raise erreur

    for chemin, _, fichiers in os.walk(dossier, onerror=illisible):
        for fichier in fichiers:
            complet = os.path.join(chemin, fichier)
            contenu[os.path.relpath(complet, dossier).replace(os.sep, '/')] = os.path.getsize(complet)
    return contenu


def forcer_ecriture(chemin):
    """Fait écrire réellement un fichier ou un dossier sur le stockage, pour qu'une coupure
    de courant ne laisse pas un fichier vide derrière un renommage. Au mieux : certains
    systèmes refusent (dossiers sous Windows), sans gravité."""
    try:
        fd = os.open(chemin, os.O_RDONLY)
    except OSError:
        return
    try:
        os.fsync(fd)
    except OSError:
        pass
    finally:
        os.close(fd)


def dossier_transaction(racine):
    return os.path.join(racine, 'script.dark-prophet', 'transaction')


def transaction_en_attente(racine):
    transaction = dossier_transaction(racine)
    return os.path.isdir(transaction) or os.path.isdir(transaction + '.fin')


def noter_etape(transaction, etape):
    provisoire = os.path.join(transaction, 'etape.tmp')
    with open(provisoire, 'w') as sortie:
        sortie.write(etape)
        sortie.flush()
        os.fsync(sortie.fileno())
    os.replace(provisoire, os.path.join(transaction, 'etape'))
    forcer_ecriture(transaction)


def lire_etape(transaction):
    try:
        with open(os.path.join(transaction, 'etape')) as source:
            return source.read().strip()
    except OSError:
        return ''


def chemins_du_dossier(racine, transaction, dossier):
    return (os.path.join(racine, dossier), os.path.join(transaction, 'nouveau', dossier),
            os.path.join(transaction, 'ancien', dossier))


def basculer(racine, transaction, garde=lambda: None):
    """Met les dossiers préparés en place. Chaque pas peut être rejoué après une coupure."""
    for dossier in DOSSIERS:
        garde()
        actuel, nouveau, ancien = chemins_du_dossier(racine, transaction, dossier)
        if os.path.isdir(nouveau):
            if os.path.lexists(actuel):
                if os.path.lexists(ancien):
                    # L'ancien est déjà de côté : `actuel` a été recréé entre-temps (Kodi,
                    # réglages par défaut). Le nouveau contenu, complet, le remplace.
                    shutil.rmtree(actuel)
                else:
                    os.makedirs(os.path.dirname(ancien), exist_ok=True)
                    os.replace(actuel, ancien)
            os.replace(nouveau, actuel)
        elif not os.path.lexists(actuel) and os.path.isdir(ancien):
            os.replace(ancien, actuel)   # ne devrait pas arriver : on ne laisse jamais un dossier manquer
    forcer_ecriture(racine)


def annuler(racine, transaction):
    """Échec pendant la bascule : remet les dossiers d'avant. L'étape « annulation » est
    notée d'abord : une annulation interrompue est terminée à la reprise (on ne réinstalle
    pas ce qui vient d'échouer). Chaque pas peut être rejoué ; le nouveau contenu retourne
    dans `nouveau`."""
    noter_etape(transaction, 'annulation')
    for dossier in DOSSIERS:
        actuel, nouveau, ancien = chemins_du_dossier(racine, transaction, dossier)
        if os.path.lexists(nouveau):
            if os.path.lexists(actuel) and os.path.lexists(ancien):
                shutil.rmtree(actuel)   # recréé entre-temps
        elif os.path.lexists(actuel):
            os.replace(actuel, nouveau)   # le nouveau était en place : on le remet de côté
        if os.path.isdir(ancien):
            os.replace(ancien, actuel)
    noter_etape(transaction, 'annulee')


def jeter(transaction):
    """Efface un dossier de transaction terminé : renommé d'abord, pour qu'un effacement
    interrompu ne soit jamais pris pour une transaction à reprendre."""
    fin = transaction + '.fin'
    shutil.rmtree(fin, ignore_errors=True)
    if os.path.isdir(transaction):
        os.replace(transaction, fin)
    shutil.rmtree(fin, ignore_errors=True)


def reprendre(racine):
    """Termine ou annule une application interrompue dans ce profil (coupure, arrêt de
    Kodi). Renvoie 'terminee', 'annulee', 'abandonnee' ou None (rien en attente). À n'appeler que
    lorsque l'habillage n'est pas chargé dans ce profil. Lève OSError en cas d'échec :
    la transaction reste alors intacte pour une nouvelle tentative."""
    transaction = dossier_transaction(racine)
    resultat = None
    if os.path.isdir(transaction):
        etape = lire_etape(transaction)
        if etape == 'bascule':
            basculer(racine, transaction)
            noter_etape(transaction, 'terminee')
            resultat = 'terminee'
        elif etape == 'annulation':
            annuler(racine, transaction)
            resultat = 'annulee'
        elif etape == 'terminee':
            resultat = 'terminee'
        else:
            resultat = 'abandonnee'
        log('application interrompue dans %s : %s' % (racine, resultat))
    jeter(transaction)
    return resultat


OCCUPE = ("Une autre opération de DaRk-PrOphEt est en cours sur ce profil.[CR]"
          "Attends qu'elle se termine, puis relance. Si ce message revient, redémarre Kodi. "
          "Rien n'a été modifié.")
# Le verrou d'un profil désigne son opération (identifiant) et le processus qui la mène (numéro et
# heure de départ, lus dans /proc). Il n'est repris que sur preuve que l'opération ne peut plus
# rien faire : appareil redémarré, ou ce processus précis disparu. Un processus encore là n'est
# jamais dépossédé, même figé (veille, stockage lent) : un délai ne prouve rien.
# Sans /proc (Windows, macOS…), seul reste le battement : réécrit toutes les BATTEMENT secondes
# par un fil à part, le verrou est jugé abandonné sans battement depuis ABANDON secondes.
BATTEMENT = 5
ABANDON = 120
# Verrou resté vide : son créateur est mort entre la création et l'écriture (un instant en temps normal).
ABANDON_VIDE = 30


def horloge_demarrage():
    """(identifiant du démarrage de l'appareil, secondes depuis ce démarrage) : insensible aux
    changements d'heure et comparable entre processus. Ailleurs que sous Linux/Android : ('', heure)."""
    try:
        with open('/proc/sys/kernel/random/boot_id') as source:
            demarrage = source.read().strip()
        return demarrage, time.clock_gettime(time.CLOCK_BOOTTIME)
    except (OSError, AttributeError, ValueError):
        return '', time.time()


def empreinte_processus(pid):
    """Heure de départ du processus `pid` (lue dans /proc) : avec son numéro, elle désigne ce
    processus précis, même si le numéro est réutilisé ensuite. '' s'il n'existe plus ; None si
    on ne peut pas le savoir (pas de /proc, accès refusé, format inattendu)."""
    try:
        with open('/proc/%d/stat' % int(pid)) as source:
            return source.read().rsplit(')', 1)[1].split()[19]
    except FileNotFoundError:
        return '' if os.path.isfile('/proc/self/stat') else None
    except (OSError, IndexError, ValueError, TypeError):
        return None


def candidats_vivants(fichier, sauf, avant_ns):
    """Nombre d'opérations en train de prendre ce verrou dont le processus existe encore : chacune
    dépose un fichier « candidat » portant son identité AVANT de créer le verrou ou une marque.
    Seuls comptent les candidats déposés au plus tard à `avant_ns` (date du fichier resté vide) :
    les suivants ne peuvent pas l'avoir créé. Les candidats d'un processus disparu, ou d'un autre
    démarrage de l'appareil, sont effacés."""
    dossier, nom = os.path.split(fichier)
    actuel = horloge_demarrage()[0]
    vivants = 0
    for entree in os.listdir(dossier):
        if not entree.startswith(nom + '.candidat.') or entree == '%s.candidat.%s' % (nom, sauf):
            continue
        chemin = os.path.join(dossier, entree)
        try:
            if os.stat(chemin).st_mtime_ns > avant_ns:
                continue
            with open(chemin) as source:
                candidat = json.load(source)
            processus, demarrage = candidat['processus'], candidat['demarrage']
        except (OSError, ValueError, KeyError, TypeError):
            continue   # en cours d'écriture : son auteur n'a pas encore créé de verrou
        present = empreinte_processus(candidat.get('pid'))
        if (demarrage and actuel and demarrage != actuel) or (present is not None and present != processus):
            try:
                os.remove(chemin)
            except OSError:
                pass
        else:
            vivants += 1
    return vivants


def etat_verrou(chemin, principal, sauf):
    """(abandonné ?, identité). Abandonné seulement sur preuve ; dans le doute, False. L'identité
    est l'identifiant de l'opération, ou « vide-<inode> » pour un verrou pas encore écrit.
    principal : le verrou dont dépendent les candidats ; sauf : notre propre identifiant.
    Lève OSError s'il a disparu ou est illisible."""
    with open(chemin) as source:
        contenu = source.read()
        infos = os.fstat(source.fileno())
    try:
        detenteur = json.loads(contenu)
        identifiant, demarrage, battement = detenteur['id'], detenteur['demarrage'], float(detenteur['battement'])
    except (ValueError, KeyError, TypeError):
        # Vide ou incomplet : son créateur a été arrêté entre la création et l'écriture. Abandonné
        # si aucun candidat n'est encore vivant ; sans /proc, si c'est vieux de ABANDON_VIDE.
        identite = 'vide-%d' % infos.st_ino
        if empreinte_processus(os.getpid()) is None:
            return time.time() - infos.st_mtime > ABANDON_VIDE, identite
        return candidats_vivants(principal, sauf, infos.st_mtime_ns) == 0, identite
    actuel, maintenant = horloge_demarrage()
    if demarrage and actuel and demarrage != actuel:
        return True, identifiant   # l'appareil a redémarré depuis
    processus = detenteur.get('processus')
    present = empreinte_processus(detenteur.get('pid')) if processus else None
    if present is not None:
        return present != processus, identifiant
    # Sans /proc : le battement décide.
    if demarrage != actuel:
        return False, identifiant  # horloges non comparables : prudence
    if demarrage and os.path.isdir('/proc/self') and not os.path.exists('/proc/%s' % detenteur.get('pid')):
        return True, identifiant
    return maintenant - battement > ABANDON, identifiant   # écart négatif (heure reculée) : on ne vole pas


def ecrire_verrou(fichier, contenu):
    provisoire = '%s.%s' % (fichier, contenu['id'])
    with open(provisoire, 'w') as sortie:
        json.dump(contenu, sortie)
    os.replace(provisoire, fichier)


def proprietaire_du_verrou(fichier):
    try:
        with open(fichier) as source:
            return json.load(source).get('id')
    except (OSError, ValueError, AttributeError):
        return None


def prendre_marque(fichier, identite, contenu):
    """Marque exclusive pour reprendre le verrou abandonné `identite`. Si le repreneur qui la
    tient a disparu, on passe à la suivante, dont le nom est le même pour tous : une seule
    opération l'obtient. Aucune marque n'est jamais retirée par un concurrent. Renvoie son
    chemin, ou None si un repreneur vivant est déjà dessus."""
    marque = '%s.reprise.%s' % (fichier, identite)
    for _ in range(5):
        try:
            fd = os.open(marque, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
        except FileExistsError:
            try:
                abandonne, autre = etat_verrou(marque, fichier, contenu['id'])
            except OSError:
                return None   # retirée à l'instant : la reprise vient d'aboutir
            if not abandonne:
                return None
            marque = '%s.%s' % (marque, autre)
            continue
        with os.fdopen(fd, 'w') as sortie:
            json.dump(contenu, sortie)
        return marque
    return None


def reprendre_verrou(fichier, identite, contenu):
    """Remplace d'un coup le verrou abandonné `identite` par `contenu`, sous une marque exclusive
    (voir prendre_marque). Le verrou est relu sous la marque : s'il a changé entre-temps, on n'y
    touche pas. Il n'est jamais retiré ni déplacé : personne ne peut prendre sa place pendant la
    reprise. Les marques de ce verrou-là sont effacées ensuite. True si repris."""
    if not prendre_marque(fichier, identite, contenu):
        return False
    try:
        try:
            if etat_verrou(fichier, fichier, contenu['id']) != (True, identite):
                return False
        except OSError:
            return False
        ecrire_verrou(fichier, contenu)
        return True
    finally:
        dossier, nom = os.path.split(fichier)
        prefixe = '%s.reprise.%s' % (nom, identite)
        for entree in os.listdir(dossier):
            if entree == prefixe or entree.startswith(prefixe + '.'):
                try:
                    os.remove(os.path.join(dossier, entree))
                except OSError:
                    pass


PERDU = ("Une autre opération a repris la main sur ce profil.[CR]"
         "Celle-ci s'est arrêtée sans rien modifier de plus.")


@contextlib.contextmanager
def verrou(racine):
    """Un seul lancement à la fois touche aux réglages d'un profil (assistant, service,
    deux assistants). Le verrou porte un identifiant d'opération ; seule cette opération
    le retire. Un verrou abandonné (voir etat_verrou) est repris ; dans le doute,
    on refuse : lève PackNonApplique sans rien modifier. Fournit garde() : à appeler avant
    chaque étape qui modifie des fichiers ; lève PackNonApplique si le verrou a été perdu."""
    dossier = os.path.join(racine, 'script.dark-prophet')
    fichier = os.path.join(dossier, 'verrou')
    identifiant = '%032x' % random.SystemRandom().getrandbits(128)
    candidat = '%s.candidat.%s' % (fichier, identifiant)
    cree = False
    try:
        os.makedirs(dossier, exist_ok=True)
        demarrage, battement = horloge_demarrage()
        contenu = {'id': identifiant, 'pid': os.getpid(), 'processus': empreinte_processus(os.getpid()),
                   'demarrage': demarrage, 'battement': battement}
        with open(candidat, 'w') as sortie:   # avant le verrou : un verrou vide reste attribuable
            json.dump(contenu, sortie)
        for _ in range(3):
            try:
                fd = os.open(fichier, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
            except FileExistsError:
                try:
                    abandonne, ancien = etat_verrou(fichier, fichier, identifiant)
                except OSError:
                    continue   # retiré à l'instant (fin de l'autre opération) : on réessaie
                if not abandonne:
                    raise PackNonApplique(OCCUPE)
                if reprendre_verrou(fichier, ancien, contenu):
                    log('verrou abandonné repris dans %s' % racine)
                    cree = True
                    break
                continue
            cree = True
            os.close(fd)
            ecrire_verrou(fichier, contenu)
            break
        else:
            raise PackNonApplique(OCCUPE)
    except OSError as erreur:
        log('verrou impossible dans %s : %r' % (racine, erreur))
        restes = ['%s.%s' % (fichier, identifiant)]
        if cree and proprietaire_du_verrou(fichier) in (None, identifiant):
            restes.append(fichier)   # le nôtre, vide ou complet
        for reste in restes:
            try:
                os.remove(reste)
            except OSError:
                pass
        raise PackNonApplique("Les réglages de ce profil ne sont pas modifiables (%s).[CR]"
                              "Rien n'a été modifié." % cause(erreur))
    finally:
        try:
            os.remove(candidat)
        except OSError:
            pass
    try:
        candidats_vivants(fichier, identifiant, time.time_ns())   # efface ceux des opérations disparues
    except OSError:
        pass
    fin = threading.Event()

    def battre():
        while not fin.wait(BATTEMENT):
            if proprietaire_du_verrou(fichier) != identifiant:
                return   # verrou perdu (jugé abandonné) : ne pas écraser celui d'un autre
            try:
                ecrire_verrou(fichier, dict(contenu, battement=horloge_demarrage()[1]))
            except OSError as erreur:
                log('battement du verrou : %r' % erreur)

    def garde():
        if proprietaire_du_verrou(fichier) != identifiant:
            log('verrou perdu dans %s : arrêt sans rien modifier' % racine)
            raise PackNonApplique(PERDU)

    battant = threading.Thread(target=battre, daemon=True)
    battant.start()
    try:
        yield garde
    finally:
        fin.set()
        battant.join(BATTEMENT + 1)
        if proprietaire_du_verrou(fichier) == identifiant:
            try:
                os.remove(fichier)
            except OSError as erreur:
                log('verrou non retiré : %r' % erreur)
        else:
            log('verrou d\'une autre opération laissé en place dans %s' % racine)


def remplacer_dossiers(racine, preparer, attendu):
    with verrou(racine) as garde:
        _remplacer_dossiers(racine, preparer, attendu, garde)


def _remplacer_dossiers(racine, preparer, attendu, garde=lambda: None):
    """Remplace les dossiers DOSSIERS de `racine` sans jamais les laisser à moitié écrits.
    preparer(dossier) écrit le nouveau contenu dans `dossier` (un sous-dossier par entrée
    de DOSSIERS, déjà créé). attendu : {chemin relatif : taille} de ce qui doit en sortir.
    Lève PackNonApplique si les réglages n'ont pas été remplacés."""
    transaction = dossier_transaction(racine)
    try:
        reprendre(racine)
    except OSError as erreur:
        log('reprise impossible dans %s : %r' % (racine, erreur))
        raise PackNonApplique("Une installation précédente n'a pas pu être terminée (%s).[CR]"
                              "Rien de plus n'a été modifié." % cause(erreur))
    try:
        verifier_place(racine, sum(attendu.values()) + 4096 * len(attendu))
        os.makedirs(transaction)
        noter_etape(transaction, 'preparation')
        nouveau = os.path.join(transaction, 'nouveau')
        for dossier in DOSSIERS:
            os.makedirs(os.path.join(nouveau, dossier))
        preparer(nouveau)
        if inventaire(nouveau) != attendu:
            raise OSError('contenu préparé incomplet')
        # Les renommages ne déplacent rien que si tout est sur le même stockage.
        if os.stat(nouveau).st_dev != os.stat(racine).st_dev:
            raise OSError(errno.EXDEV, os.strerror(errno.EXDEV))
        garde()   # perdu : on laisse la préparation à celui qui a repris (sa reprise la jettera)
        noter_etape(transaction, 'bascule')
    except (OSError, zipfile.BadZipFile, zlib.error) as erreur:
        log('préparation abandonnée dans %s : %r' % (racine, erreur))
        try:
            jeter(transaction)
        except OSError:
            pass   # rien n'a été basculé : la prochaine reprise jettera la préparation
        raise PackNonApplique("Les nouveaux réglages n'ont pas pu être préparés (%s).[CR]"
                              "Tes réglages actuels n'ont pas été modifiés." % cause(erreur))
    try:
        basculer(racine, transaction, garde)
    except OSError as erreur:
        log('bascule interrompue dans %s : %r' % (racine, erreur))
        garde()
        try:
            annuler(racine, transaction)
            jeter(transaction)
        except OSError as autre:
            log('annulation impossible : %r' % autre)
            if lire_etape(transaction) == 'annulation':
                raise PackNonApplique("Les nouveaux réglages n'ont pas pu être mis en place (%s).[CR]"
                                      "Tes réglages précédents seront remis au prochain lancement de DaRk-PrOphEt."
                                      % cause(erreur))
            raise PackNonApplique("La mise en place des réglages a été interrompue (%s).[CR]"
                                  "Elle sera terminée au prochain lancement de DaRk-PrOphEt." % cause(erreur))
        raise PackNonApplique("Les nouveaux réglages n'ont pas pu être mis en place (%s).[CR]"
                              "Tes réglages précédents ont été remis." % cause(erreur))
    try:
        noter_etape(transaction, 'terminee')
        jeter(transaction)
    except OSError as erreur:
        log('transaction gardée, effacée au prochain lancement : %r' % erreur)


def ecrire_pack(archive, racine):
    """Remplace les réglages d'habillage de `racine` par ceux du pack (voir
    remplacer_dossiers). Renvoie le nombre de fichiers écrits ; lève PackNonApplique
    si rien n'a été changé."""
    try:
        raison = verifier_pack(archive)
    except zipfile.BadZipFile as erreur:
        raison = str(erreur)
    if raison:
        raise PackNonApplique("La configuration téléchargée est inutilisable (%s).[CR]"
                              "Tes réglages actuels n'ont pas été modifiés." % raison)
    membres = [(info, os.path.relpath(cible, racine).replace(os.sep, '/'))
               for info, cible in membres_autorises(archive, racine)]

    def preparer(nouveau):
        for info, relatif in membres:
            cible = os.path.join(nouveau, *relatif.split('/'))
            os.makedirs(os.path.dirname(cible), exist_ok=True)
            with archive.open(info) as source, open(cible, 'wb') as sortie:
                shutil.copyfileobj(source, sortie)
                sortie.flush()
                os.fsync(sortie.fileno())

    remplacer_dossiers(racine, preparer, {relatif: info.file_size for info, relatif in membres})
    return len(membres)


def taille_dossiers(racine):
    return sum(taille + 4096 for dossier in DOSSIERS
               for taille in inventaire(os.path.join(racine, dossier)).values())


def sauvegarder_actuel():
    """Copie des réglages d'habillage d'AVANT la première installation : c'est
    elle que « Réinitialiser les réglages » remet. On ne la remplace donc pas
    aux installations et mises à jour suivantes. Elle est copiée à côté puis
    renommée : un dossier « sauvegarde » présent est toujours complet ; une copie
    interrompue (sauvegarde.tmp) est refaite à la tentative suivante. Lève
    PackNonApplique en cas d'échec : il ne faut alors rien remplacer."""
    if os.path.isdir(SAUVEGARDE):
        return
    with verrou(ADDON_DATA) as garde:
        _sauvegarder(garde)


def _sauvegarder(garde=lambda: None):
    provisoire = SAUVEGARDE + '.tmp'
    try:
        shutil.rmtree(provisoire, ignore_errors=True)
        verifier_place(ADDON_DATA, taille_dossiers(ADDON_DATA))
        os.makedirs(provisoire)
        attendu = {}
        for dossier in DOSSIERS:
            source = os.path.join(ADDON_DATA, dossier)
            if os.path.isdir(source):
                shutil.copytree(source, os.path.join(provisoire, dossier))
                attendu.update({dossier + '/' + relatif: taille for relatif, taille in inventaire(source).items()})
        if inventaire(provisoire) != attendu:
            raise OSError('copie incomplète')
        for relatif in attendu:
            forcer_ecriture(os.path.join(provisoire, *relatif.split('/')))
        garde()
        os.replace(provisoire, SAUVEGARDE)
        forcer_ecriture(os.path.dirname(SAUVEGARDE))
    except OSError as erreur:
        log('sauvegarde impossible : %r' % erreur)
        shutil.rmtree(provisoire, ignore_errors=True)
        raise PackNonApplique("La sauvegarde de tes réglages actuels n'a pas pu être faite (%s).[CR]"
                              "Rien n'a été modifié." % cause(erreur))


def remettre_sauvegarde():
    """Remet les réglages d'habillage d'avant la première installation (voir
    remplacer_dossiers). La sauvegarde est copiée, jamais déplacée : elle reste
    intacte si la remise échoue. Lève PackNonApplique dans ce cas."""
    attendu = {}
    try:
        for dossier in DOSSIERS:
            attendu.update({dossier + '/' + relatif: taille
                            for relatif, taille in inventaire(os.path.join(SAUVEGARDE, dossier)).items()})
        # Une sauvegarde d'avant la 1.17.7 n'a jamais été vérifiée : on refuse au moins
        # de remettre des réglages d'habillage illisibles.
        reglages = os.path.join(SAUVEGARDE, SKIN, 'settings.xml')
        if os.path.isfile(reglages):
            ElementTree.parse(reglages)
    except (OSError, ElementTree.ParseError) as erreur:
        log('sauvegarde illisible : %r' % erreur)
        raise PackNonApplique("La sauvegarde des réglages d'origine est illisible (%s).[CR]"
                              "Rien n'a été modifié." % cause(erreur))

    def preparer(nouveau):
        for dossier in DOSSIERS:
            source = os.path.join(SAUVEGARDE, dossier)
            if os.path.isdir(source):
                shutil.copytree(source, os.path.join(nouveau, dossier), dirs_exist_ok=True)
        for relatif in attendu:
            forcer_ecriture(os.path.join(nouveau, *relatif.split('/')))

    remplacer_dossiers(ADDON_DATA, preparer, attendu)


def hors_de_l_habillage(action):
    """Kodi réécrit les réglages de l'habillage actif quand il le quitte : on
    passe donc sur l'habillage d'origine le temps de toucher aux fichiers.
    L'habillage est remis même si `action` échoue (l'erreur suit son cours)."""
    if xbmc.getSkinDir() == SKIN and not changer_habillage(SKIN_SECOURS):
        dialog.ok(TITRE, "Impossible de quitter l'habillage pour appliquer les réglages.")
        return False
    try:
        action()
    finally:
        actif = changer_habillage(SKIN)
    return actif


def reprendre_au_lancement():
    """Assistant : une application interrompue dans ce profil est terminée tout de suite,
    l'habillage étant quitté le temps de toucher aux fichiers."""
    if not transaction_en_attente(ADDON_DATA):
        return
    actif = xbmc.getSkinDir() == SKIN
    if actif and not changer_habillage(SKIN_SECOURS):
        return   # on réessaiera au prochain lancement ; rien n'est perdu
    try:
        with verrou(ADDON_DATA):
            resultat = reprendre(ADDON_DATA)
        if resultat == 'terminee':
            dialog.ok(TITRE, "Une mise en place de l'interface avait été interrompue : elle est maintenant terminée.")
        elif resultat == 'annulee':
            dialog.ok(TITRE, "Une mise à jour de l'interface avait échoué : tes réglages précédents sont remis.")
    except PackNonApplique as erreur:
        dialog.ok(TITRE, str(erreur))
    except OSError as erreur:
        log('reprise impossible : %r' % erreur)
        dialog.ok(TITRE, "Une installation interrompue n'a pas pu être terminée (%s).[CR]"
                         "Rien n'a été effacé. Libère de la place puis relance." % cause(erreur))
    finally:
        if actif:
            changer_habillage(SKIN)


def reprendre_au_demarrage():
    """Service : termine une application interrompue seulement si Arctic Fuse 3 n'est
    pas l'habillage de ce profil (Kodi réécrit les réglages de l'habillage actif en le
    quittant). Sinon on prévient, et l'assistant s'en chargera à son lancement."""
    if not transaction_en_attente(ADDON_DATA):
        return
    if xbmc.getSkinDir() == SKIN:
        log('application interrompue : reprise au prochain lancement du script')
        xbmc.executebuiltin('Notification(%s,Installation interrompue - relance %s pour la terminer,10000)' % (TITRE, TITRE))
        return
    try:
        with verrou(ADDON_DATA):
            reprendre(ADDON_DATA)
    except (OSError, PackNonApplique) as erreur:
        log('reprise impossible ou reportée : %s' % erreur)


def appliquer_ici(archive, fond=None, bouton_catchup=None, vstream=None):
    """Applique un pack au profil ouvert et active l'habillage.
    bouton_catchup, vstream : True ou False pour ajuster le bouton Catch-up TV du
    menu Options et les rubriques de l'accueil (profil alkoFlix seulement)."""
    if archive is None:
        return changer_habillage(SKIN)

    def appliquer():
        sauvegarder_actuel()
        log('%s fichiers écrits' % ecrire_pack(archive, ADDON_DATA))
        if fond:
            poser_fond(fond)
        ajuster_menu_options(bouton_catchup)
        if vstream is not None:
            ajuster_rubriques_vstream(vstream)

    return hors_de_l_habillage(appliquer)


def ajuster_menu_options(avec_catchup=None, racine=None):
    """Menu Options d'Arctic Fuse 3 : la tuile CPU/RAM devient le passage vers
    l'autre profil (Catch-up TV depuis alkoFlix, seulement s'il existe ;
    alkoFlix depuis Catch-up TV, d'où racine, l'addon_data du profil fermé), la
    liste perd « Favoris » et « Gestionnaire des fichiers » et gagne « Extensions »
    et un raccourci vers ce script. avec_catchup None : on ne touche pas au
    passage entre profils."""
    fichier = os.path.join(racine or ADDON_DATA, 'script.skinvariables', 'nodes', SKIN, 'skinvariables-shortcut-powermenu.json')
    vers = (PROFIL_ALKOFLIX, 'film.png') if racine else (PROFIL_CATCHUP, 'livetv.png') if avec_catchup else None
    try:
        with open(fichier, encoding='utf-8') as source:
            entrees = [e for e in json.load(source) if e.get('guid') not in GUIDS_MENU_OPTIONS]
        # Juste avant « Quitter », qui reste en dernier.
        for entree in (
                {'icon': 'special://skin/extras/icons/puzzle-piece.png', 'label': 'Extensions',
                 'path': 'ActivateWindow(addonbrowser)', 'target': '', 'guid': 'guid-dpextensions'},
                {'icon': 'special://skin/extras/icons/%s' % ICONE_SCRIPT, 'label': TITRE,
                 'path': 'RunScript(script.dark-prophet)', 'target': '', 'guid': 'guid-dpscript'}):
            entrees.insert(max(len(entrees) - 1, 0), entree)
        with open(fichier, 'w', encoding='utf-8') as sortie:
            json.dump(entrees, sortie, indent=4, ensure_ascii=False)
    except (OSError, ValueError) as erreur:
        log('menu Options : %r' % erreur)
        return
    if vers:
        poser_tuile_options(vers[0], 'LoadProfile(%s)' % vers[0], 'special://skin/extras/icons/%s' % vers[1], racine)
    elif avec_catchup is not None:
        poser_tuile_options(None, None, None, racine)


def poser_tuile_options(label, action, icone, racine=None):
    """Troisième tuile du menu Options : un bouton à notre nom, ou, sans label,
    la tuile CPU/RAM d'origine."""
    reglages = {'optionstiles.03.include': 'Custom' if label else 'SystemInfo', 'optionstiles.03.label': label or '',
                'optionstiles.03.path': action or '', 'optionstiles.03.icon': icone or ''}
    for nom, valeur in reglages.items():
        poser_reglage_habillage(nom, valeur, racine)


def ajuster_rubriques_vstream(avec):
    """Rubriques de l'accueil (profil alkoFlix) : en version Full, le menu de
    vStream et sa recherche, qui trouve aussi les titres absents du catalogue
    d'alkoFlix."""
    fichier = os.path.join(ADDON_DATA, 'script.skinvariables', 'nodes', SKIN, 'skinvariables-shortcut-homesubmenu.json')
    try:
        with open(fichier, encoding='utf-8') as source:
            entrees = [e for e in json.load(source) if VSTREAM not in str(e.get('path', ''))]
        if avec:
            entrees += [
                {'label': 'vStream', 'path': 'plugin://%s/' % VSTREAM, 'icon': 'special://skin/extras/icons/addon.png',
                 'target': 'videos', 'guid': 'guid-dpvstream'},
                {'label': 'Rechercher dans vStream', 'icon': 'special://skin/extras/icons/search.png', 'target': 'videos',
                 'path': 'plugin://%s/?site=cHome&function=showMenuSearch&title=Recherche+directe&sFav=showMenuSearch' % VSTREAM,
                 'guid': 'guid-dpvstreamr'}]
        with open(fichier, 'w', encoding='utf-8') as sortie:
            json.dump(entrees, sortie, indent=4, ensure_ascii=False)
    except (OSError, ValueError) as erreur:
        log('rubriques vStream : %r' % erreur)


def couper_doublons_vstream():
    """vStream cherche dans toutes ses sources actives et range les résultats
    source par source : une source qui en copie une autre (« French-stream
    (Clone) ») ne fait que doubler les lignes de la liste. On la désactive ; le
    fichier de l'utilisateur est créé à partir de celui de l'extension s'il
    n'existe pas encore."""
    cible = os.path.join(ADDON_DATA, VSTREAM, 'sites.json')
    modele = xbmcvfs.translatePath('special://home/addons/%s/resources/sites.json' % VSTREAM)
    try:
        with open(cible if os.path.isfile(cible) else modele, encoding='utf-8') as source:
            sites = json.load(source)
        if sites['sites']['french_stream_clone'].get('active') == 'False':
            return
        sites['sites']['french_stream_clone']['active'] = 'False'
        os.makedirs(os.path.dirname(cible), exist_ok=True)
        with open(cible, 'w', encoding='utf-8') as sortie:
            json.dump(sites, sortie, indent=4)    # ASCII pur : vStream relit le fichier sans préciser l'encodage
    except (OSError, ValueError, KeyError) as erreur:
        log('doublons vStream : %r' % erreur)


def relier_vstream(avec):
    """En version Full, vStream devient un second lecteur de TMDb Helper : sur
    une fiche, un appui long propose « Lire avec… ». alkoFlix reste le
    lecteur par défaut. Le fichier vient des alKODIques (players.zip)."""
    cible = os.path.join(ADDON_DATA, TMDBHELPER, 'players', 'vstream.json')
    try:
        if avec:
            couper_doublons_vstream()
            os.makedirs(os.path.dirname(cible), exist_ok=True)
            shutil.copy(xbmcvfs.translatePath('special://home/addons/script.dark-prophet/resources/players/vstream.json'), cible)
        elif os.path.isfile(cible):
            os.remove(cible)
    except OSError as erreur:
        log('lecteur vStream : %r' % erreur)


def relier_alkoflix():
    """Les fiches et la recherche d'Arctic Fuse 3 passent par TMDb Helper : sans
    les lecteurs d'alkoFlix, un film choisi là ne propose que « Lire avec UPnP ».
    On installe ces lecteurs (fournis par alkoFlix) et on prend celui qui
    affiche la liste des liens comme lecteur par défaut."""
    source = xbmcvfs.translatePath('special://home/addons/%s/resources/players/json/' % ALKOFLIX)
    cible = os.path.join(ADDON_DATA, TMDBHELPER, 'players')
    try:
        lecteurs = [f for f in os.listdir(source) if f.endswith('.json')]
        os.makedirs(cible, exist_ok=True)
        for lecteur in lecteurs:
            shutil.copy(os.path.join(source, lecteur), cible)
        if LECTEUR in lecteurs:
            reglages = xbmcaddon.Addon(TMDBHELPER)
            reglages.setSetting('default_player_movies', LECTEUR + ' play_movie')
            reglages.setSetting('default_player_episodes', LECTEUR + ' play_episode')
    except (OSError, RuntimeError) as erreur:
        log('lecteurs alkoFlix : %r' % erreur)


def telecharger_fond(fichier):
    """Télécharge un fond d'écran du dépôt. Renvoie son chemin, ou None s'il est introuvable."""
    cible = os.path.join(DOSSIER_FONDS, fichier)
    try:
        os.makedirs(DOSSIER_FONDS, exist_ok=True)
        # Reçu en entier avant d'ouvrir le fichier : une coupure ne laisse pas une image tronquée à la place de l'ancienne.
        with urlopen(PACKS_URL + 'fonds/' + fichier, timeout=30) as reponse:
            donnees = reponse.read()
        with open(cible, 'wb') as sortie:
            sortie.write(donnees)
    except (URLError, OSError, HTTPException) as erreur:
        log('fond %s : %r' % (fichier, erreur))
        return cible if os.path.isfile(cible) else None
    return cible


def choisir_fond(redemander=True):
    """Fond d'écran du profil alkoFlix : chemin de l'image téléchargée, ou None
    pour garder celui du pack. Le choix est retenu pour les mises à jour."""
    choix = open(FICHIER_FOND).read().strip() if os.path.isfile(FICHIER_FOND) else ''
    fichiers = [fichier for _, fichier in FONDS]
    if redemander or (choix not in fichiers and choix != 'aucun'):
        numero = dialog.select("Quel fond d'écran ?", [nom for nom, _ in FONDS] + ["Celui d'Arctic Fuse 3"])
        choix = fichiers[numero] if 0 <= numero < len(fichiers) else 'aucun'
        os.makedirs(DOSSIER_FONDS, exist_ok=True)
        with open(FICHIER_FOND, 'w') as sortie:
            sortie.write(choix)
    return None if choix == 'aucun' else telecharger_fond(choix)


def changer_fond():
    """Change le fond d'écran du profil alkoFlix à tout moment, sans rien réinstaller."""
    numero = dialog.select("Quel fond d'écran ?", [nom for nom, _ in FONDS] + ["Celui d'Arctic Fuse 3"])
    if numero < 0:
        return
    choix = FONDS[numero][1] if numero < len(FONDS) else 'aucun'
    image = FOND_HABILLAGE if choix == 'aucun' else telecharger_fond(choix)
    if image is None:
        dialog.ok(TITRE, 'Téléchargement impossible. Vérifie la connexion puis relance.')
        return
    os.makedirs(DOSSIER_FONDS, exist_ok=True)
    with open(FICHIER_FOND, 'w') as sortie:
        sortie.write(choix)
    xbmc.executebuiltin('Skin.SetString(Background.Image,%s)' % image)


def poser_fond(image, racine=None):
    """Inscrit le fond dans les réglages de l'habillage d'un profil, pendant qu'il n'y est pas actif."""
    poser_reglage_habillage('background.image', image, racine)


def poser_reglage_habillage(nom, valeur, racine=None):
    """Pose un réglage texte de l'habillage dans le profil dont l'addon_data est
    `racine` (le profil ouvert par défaut), pendant qu'il n'y est pas actif."""
    fichier = os.path.join(racine or ADDON_DATA, SKIN, 'settings.xml')
    if not os.path.isfile(fichier):
        return
    with open(fichier, encoding='utf-8') as source:
        xml = source.read()
    ligne = '<setting id="%s" type="string">%s</setting>' % (nom, valeur.replace('&', '&amp;'))
    motif = re.compile(r'<setting id="%s" type="string">.*?</setting>|<setting id="%s" type="string" */>' % ((re.escape(nom),) * 2), re.I | re.S)
    xml = motif.sub(lambda m: ligne, xml) if motif.search(xml) else xml.replace('</settings>', '    %s\n</settings>' % ligne)
    with open(fichier, 'w', encoding='utf-8') as sortie:
        sortie.write(xml)


def poser_images_habillage(telecharger=True):
    """Fait afficher notre image sur la case « Plus… » d'Arctic Fuse 3. Avec
    telecharger=False (au démarrage de Kodi), on se contente de repointer la
    ligne si une mise à jour de l'habillage l'a remise. Prend effet au
    prochain chargement de l'habillage."""
    copie = os.path.join(DOSSIER_IMAGES, IMAGE_PLUS)
    try:
        if telecharger:
            os.makedirs(DOSSIER_IMAGES, exist_ok=True)
            with urlopen(PACKS_URL + 'images/' + IMAGE_PLUS, timeout=30) as reponse:
                donnees = reponse.read()
            with open(copie, 'wb') as sortie:
                sortie.write(donnees)
        if os.path.isfile(copie):
            remplacer_dans_habillage(PLUS_ORIGINE, PLUS_REMPLACEE)
    except (URLError, OSError, HTTPException) as erreur:
        log('image « Plus » : %r' % erreur)


def remplacer_dans_habillage(avant, apres):
    fichier = xbmcvfs.translatePath('special://home/addons/%s/1080i/Includes_Objects.xml' % SKIN)
    if not os.path.isfile(fichier):
        return
    with open(fichier, encoding='utf-8') as source:
        xml = source.read()
    if avant in xml:
        with open(fichier, 'w', encoding='utf-8') as sortie:
            sortie.write(xml.replace(avant, apres))


def fermer_fenetres():
    """Ferme ce qu'un pilotage interrompu aurait laissé ouvert (clavier, fenêtre de profil)."""
    for _ in range(4):
        if not xbmc.getCondVisibility('System.HasActiveModalDialog'):
            break
        xbmc.executebuiltin('Action(Back)')
        xbmc.sleep(500)


def attendre_le_calme(maximum=60):
    """À sa première activation, Arctic Fuse 3 fabrique ses menus puis se
    recharge : tout pilotage lancé pendant ce temps est perdu. On attend
    quelques secondes sans fenêtre de travail."""
    moniteur = xbmc.Monitor()
    calme = 0
    for _ in range(maximum * 2):
        occupe = xbmc.getCondVisibility(
            'Window.IsVisible(progressdialog) | Window.IsVisible(busydialog) | '
            'Window.IsVisible(busydialognocancel) | Window.IsActive(startup)')
        calme = 0 if occupe else calme + 1
        if calme >= 12 or moniteur.waitForAbort(0.5):
            return


def insister(action, *arguments):
    """Rejoue un pilotage d'écran qui a échoué, après avoir remis Kodi au propre."""
    for _ in range(3):
        if action(*arguments):
            return True
        fermer_fenetres()
        attendre_le_calme()
    return False


def retour_accueil():
    # Un changement de fenêtre ferme les messages ouverts : on attend qu'il
    # soit fini avant d'en afficher un.
    fermer_fenetres()
    xbmc.executebuiltin('ActivateWindow(home)')
    attendre('Window.IsActive(home)', 10)
    xbmc.sleep(700)


# --- Profils ----------------------------------------------------------------

def profils():
    return [p['label'] for p in (rpc('Profiles.GetProfiles') or {}).get('profiles', [])]


def dossier_du_profil(nom):
    """Dossier que Kodi a donné au profil, lu dans son fichier des profils."""
    for profil in ElementTree.parse(os.path.join(MAITRE, 'profiles.xml')).getroot().iter('profile'):
        if profil.findtext('name') == nom:
            return os.path.join(MAITRE, *profil.findtext('directory').strip('/').split('/'))
    return None


def ouvrir_ecran_profils():
    # Juste après son activation, Arctic Fuse 3 se recharge une fois et
    # annule l'ouverture en cours : on insiste.
    for _ in range(5):
        xbmc.executebuiltin('ActivateWindow(profiles)')
        if attendre('Window.IsActive(profiles)', 6):
            xbmc.sleep(1500)
            if xbmc.getCondVisibility('Window.IsActive(profiles)'):
                return True
    return False


def ouvrir_liste_des_profils(position):
    """Ouvre l'écran Profils de Kodi et se place sur une case de la liste."""
    if not ouvrir_ecran_profils():
        return False
    # Selon l'habillage, la liste n'apparaît qu'une fois son onglet choisi.
    for touche in ('Down', 'Down', 'Right', 'Up', 'Left', 'Down'):
        if xbmc.getCondVisibility('Control.IsVisible(%d)' % LISTE_PROFILS):
            break
        xbmc.executebuiltin('Action(%s)' % touche)
        xbmc.sleep(400)
    # En deux temps : certains habillages placent la sélection sans donner la main à la liste.
    xbmc.executebuiltin('SetFocus(%d)' % LISTE_PROFILS)
    xbmc.sleep(400)
    xbmc.executebuiltin('SetFocus(%d,%d,absolute)' % (LISTE_PROFILS, position))
    xbmc.sleep(500)
    return (xbmc.getCondVisibility('Control.HasFocus(%d)' % LISTE_PROFILS)
            and xbmc.getInfoLabel('Container(%d).CurrentItem' % LISTE_PROFILS) == str(position + 1))


def attendre_fenetre(nom, secondes):
    """Attend une fenêtre de Kodi en répondant Non aux questions qui
    s'intercalent (Arctic Fuse 3 propose par exemple d'installer une
    extension de saisie automatique dès qu'un clavier s'ouvre)."""
    moniteur = xbmc.Monitor()
    for _ in range(secondes * 4):
        if xbmc.getCondVisibility('Window.IsVisible(%s)' % nom):
            return True
        refuser_question()
        if moniteur.waitForAbort(0.25):
            return False
    return False


def refuser_question():
    if xbmc.getCondVisibility('Window.IsVisible(yesnodialog)'):
        xbmc.executebuiltin('SendClick(%d)' % BOUTON_NON)
        xbmc.sleep(600)


def saisir(texte):
    """Remplit et valide le clavier de Kodi."""
    if not attendre_fenetre('virtualkeyboard', 10):
        log('clavier : pas ouvert')
        return False
    for _ in range(3):
        # Le clavier n'accepte le texte qu'une fois son animation d'ouverture finie.
        xbmc.sleep(1000)
        refuser_question()
        rpc('Input.SendText', {'text': texte, 'done': True})
        xbmc.sleep(700)
        refuser_question()
        if not xbmc.getCondVisibility('Window.IsVisible(virtualkeyboard)'):
            return True
    log('clavier : texte refusé')
    return False


def creer_profil(nom):
    """Pilote l'écran « Ajouter un profil » de Kodi : il n'existe pas de
    commande pour créer un profil, et Kodi réécrit profiles.xml en se fermant."""
    if nom in profils():
        return True
    if not ouvrir_liste_des_profils(len(profils())):
        log('profil : liste des profils inaccessible')
        return False
    xbmc.executebuiltin('Action(Select)')
    if not saisir(nom):
        return False
    if attendre_fenetre('filebrowser', 10):
        xbmc.sleep(500)
        xbmc.executebuiltin('SendClick(%d)' % BOUTON_OK_DOSSIER)
    if not attendre_fenetre('profilesettings', 10):
        log('profil : fenêtre de réglages pas ouverte')
        return False
    xbmc.sleep(500)
    xbmc.executebuiltin('SendClick(%d)' % BOUTON_OK_REGLAGES)
    # « Copier les réglages / les sources du profil principal ? » : oui aux deux.
    for _ in range(3):
        if not attendre('Window.IsVisible(yesnodialog)', 4):
            break
        xbmc.sleep(400)
        xbmc.executebuiltin('SendClick(%d)' % BOUTON_OUI)
        xbmc.sleep(800)
    return nom in profils()


def renommer_profil_principal(nom):
    if profils()[:1] == [nom]:
        return True
    if not ouvrir_liste_des_profils(0):
        return False
    xbmc.executebuiltin('Action(Select)')
    if not attendre_fenetre('profilesettings', 10):
        return False
    xbmc.sleep(500)
    # Le nom est la première ligne, déjà sélectionnée à l'ouverture.
    xbmc.executebuiltin('Action(Select)')
    saisi = saisir(nom)
    xbmc.executebuiltin('SendClick(%d)' % BOUTON_OK_REGLAGES)
    xbmc.sleep(800)
    return saisi and profils()[:1] == [nom]


def activer_ecran_de_choix():
    if xbmc.getCondVisibility('System.HasLoginScreen'):
        return True
    if not ouvrir_ecran_profils():
        return False
    xbmc.executebuiltin('SendClick(%d)' % BOUTON_ECRAN_CHOIX)
    xbmc.sleep(800)
    return xbmc.getCondVisibility('System.HasLoginScreen')


def poser_logos():
    """Donne à chaque profil le logo de son extension sur l'écran de choix, et
    son nom au profil principal.
    Kodi n'a aucune commande pour l'image d'un profil et réécrit profiles.xml
    en se fermant : on inscrit donc les logos dans le fichier, puis on le
    protège en écriture. Au démarrage suivant Kodi le relit, et service.py
    lève la protection. Renvoie True si un logo a été posé."""
    try:
        arbre = ElementTree.parse(FICHIER_PROFILS)
        change = False
        profils_connus = list(arbre.getroot().iter('profile'))
        avec_catchup = any(profil.findtext('name') == PROFIL_CATCHUP for profil in profils_connus)
        for profil in profils_connus:
            principal = profil.findtext('id') == '0'
            nom = profil.find('name')
            # Le profil principal prend son nom ici aussi : le renommage par l'écran des profils
            # échoue sur certains appareils, et ce fichier est de toute façon relu au redémarrage.
            if principal and avec_catchup and nom is not None and nom.text != PROFIL_ALKOFLIX:
                nom.text = PROFIL_ALKOFLIX
                change = True
            logo = LOGOS[PROFIL_ALKOFLIX] if principal and avec_catchup else LOGOS.get(profil.findtext('name'))
            vignette = profil.find('thumbnail')
            # On ne remplace pas une image que quelqu'un a choisie.
            if logo and vignette is not None and not (vignette.text or '').strip():
                vignette.text = logo
                change = True
        if not change:
            return False
        os.chmod(FICHIER_PROFILS, 0o644)
        arbre.write(FICHIER_PROFILS, encoding='utf-8')
        os.chmod(FICHIER_PROFILS, 0o444)
        os.makedirs(os.path.dirname(VERROU_PROFILS), exist_ok=True)
        with open(VERROU_PROFILS, 'w') as sortie:
            sortie.write(str(os.getpid()))
        return True
    except (OSError, ElementTree.ParseError) as erreur:
        log('logos : %r' % erreur)
        return False


def lever_verrou_profils():
    """Rend profiles.xml à Kodi une fois qu'il l'a relu, c'est-à-dire après un
    redémarrage : le numéro de processus n'est plus celui noté par poser_logos."""
    if not os.path.isfile(VERROU_PROFILS):
        return
    try:
        if open(VERROU_PROFILS).read().strip() == str(os.getpid()):
            return
        os.chmod(FICHIER_PROFILS, 0o644)
        os.remove(VERROU_PROFILS)
        if os.path.isfile(PROFILS_A_EFFACER):
            # Kodi ne connaît plus ces profils : leurs dossiers (réglages, identifiants) peuvent partir.
            racine = os.path.join(MAITRE, 'profiles')
            for nom in open(PROFILS_A_EFFACER, encoding='utf-8').read().splitlines():
                dossier = os.path.normpath(os.path.join(MAITRE, nom))
                if nom and dossier.startswith(racine + os.sep):
                    shutil.rmtree(dossier, ignore_errors=True)
            os.remove(PROFILS_A_EFFACER)
    except OSError as erreur:
        log('verrou des profils : %r' % erreur)


def copier_extensions_actives(dossier):
    """Un profil neuf démarre avec toutes les extensions désactivées : on lui
    donne la liste du profil principal (habillage, Catch-up TV, ce script…)."""
    cible = os.path.join(dossier, 'Database')
    os.makedirs(cible, exist_ok=True)
    for base in glob.glob(os.path.join(MAITRE, 'Database', 'Addons*.db')):
        copie = os.path.join(cible, os.path.basename(base))
        if os.path.exists(copie):
            os.remove(copie)
        source, sortie = sqlite3.connect(base), sqlite3.connect(copie)
        try:
            with sortie:
                source.backup(sortie)
        finally:
            source.close()
            sortie.close()


def choisir_habillage_du_profil(dossier):
    """Le profil reprend les réglages généraux du principal ; on s'assure
    seulement que son habillage est bien Arctic Fuse 3."""
    fichier = os.path.join(dossier, 'guisettings.xml')
    if not os.path.isfile(fichier):
        shutil.copy(os.path.join(MAITRE, 'guisettings.xml'), fichier)
    ecrire_reglages(fichier, {'lookandfeel.skin': SKIN})


GUIDE_PROFIL = (
    "Kodi n'a pas pu créer le profil tout seul. À faire à la main :[CR]"
    "1. Paramètres > Profils > Profils > Ajouter un profil[CR]"
    "2. Nom : %s, puis OK deux fois[CR]"
    "3. Réponds « Copier » aux deux questions[CR]"
    "4. Relance ensuite cette formule." % PROFIL_CATCHUP
)


# --- Les deux formules ------------------------------------------------------

def formule_alkoflix():
    version = choisir_version()
    if not version:
        return
    if version == 'extra':
        if dialog.yesno(TITRE, "Installer alkoFlix avec l'habillage d'origine de Kodi (Estuary) ?[CR]Kodi passera en français. L'habillage actuel sera remplacé (« Réinitialiser les réglages » le remet)."):
            formule_extra()
        return
    if not dialog.yesno(TITRE, "Installer Arctic Fuse 3 et alkoFlix avec la configuration de DaRk-PrOphEt ?[CR]Kodi passera en français. Les réglages actuels de cet habillage seront remplacés (« Réinitialiser les réglages » les remet)."):
        return
    libre = place_manquante_arctic()
    if libre is not None:
        if dialog.yesno(TITRE, "Il reste %d Mo libres : Arctic Fuse 3 et ses extensions en demandent environ %d pendant l'installation.[CR]"
                               "Rien n'a été installé. Installer plutôt la version Extra-Light (environ 100 Mo, habillage d'origine de Kodi) ?"
                        % (libre, BESOIN_ARCTIC // (1000 * 1000))):
            formule_extra()
        return
    noter_etat_avant()
    if not installer_tout((LANGUE, SONS, SAISIE, SKIN, ALKOFLIX, ICONES) + ((VSTREAM, DNS, INTRO) if version == 'full' else ()) + (FLUX, YOUTUBE, UPNEXT)):
        # Jamais de bascule d'office : on propose l'Extra-Light, qui n'a pas besoin d'Arctic Fuse 3.
        if not installe(SKIN) and dialog.yesno(TITRE, "Installer plutôt la version Extra-Light ?[CR]alkoFlix avec l'habillage d'origine de Kodi (Estuary), sans Arctic Fuse 3."):
            formule_extra()
        return
    franciser()
    regler_confort()
    relier_alkoflix()
    relier_vstream(version == 'full')
    poser_images_habillage()
    archive = telecharger_pack_alkoflix(version)
    if not appliquer_ici(archive, choisir_fond(), PROFIL_CATCHUP in profils(), version == 'full'):
        dialog.ok(TITRE, "Réglages copiés, mais l'habillage n'a pas pu être activé.[CR]Active Arctic Fuse 3 dans Paramètres > Interface.")
    elif archive is None:
        annoncer("Arctic Fuse 3 et alkoFlix sont installés.[CR]La configuration n'est pas encore publiée : l'habillage garde ses réglages.")
    else:
        annoncer("C'est installé.[CR]Si des menus manquent, redémarre Kodi une fois.")


_CATALOGUE = 'plugin://plugin.video.alkoflix/?name=%s&iconImage=%s&mode=catalogue.alkopaste_%s'
# Les catégories de l'Extra-Light : les mêmes que les pages des autres versions. Estuary n'a pas de rubriques
# personnalisables, mais le bouton « Favoris » de son accueil affiche une rangée de raccourcis.
CATEGORIES_ESTUARY = (
    ('Films', 'movies.png', _CATALOGUE % ('Films', 'movies.png', 'section&catalogue_section=films&catalogue_media_type=film')),
    ('Séries', 'tv.png', _CATALOGUE % ('S%C3%A9ries', 'tv.png', 'section&catalogue_section=series&catalogue_media_type=serie')),
    ('Dessins animés', 'genre_animation.png', _CATALOGUE % ('Dessins+anim%C3%A9s', 'genre_animation.png', 'folder&catalogue_folder=animation')),
    ('Autres', 'genre_documentary.png', _CATALOGUE % ('Docus+%26+T%C3%A9l%C3%A9', 'genre_documentary.png', 'folder&catalogue_folder=documentaries')),
    ('Favoris alkoFlix', 'favourites.png', _CATALOGUE % ('Favoris', 'favourites.png', 'global_favourites')),
)


def poser_categories_estuary():
    """Ajoute les catégories d'alkoFlix aux favoris de Kodi (une seule fois chacune)."""
    existants = {f.get('title') for f in (rpc('Favourites.GetFavourites') or {}).get('favourites') or []}
    icones = 'special://home/addons/%s/resources/skins/Default/media/' % ALKOFLIX
    for titre, icone, chemin in CATEGORIES_ESTUARY:
        if titre not in existants:
            rpc('Favourites.AddFavourite', {'title': titre, 'type': 'window', 'window': 'videos',
                                            'windowparameter': chemin, 'thumbnail': icones + icone})
    if 'Rechercher' not in existants:
        rpc('Favourites.AddFavourite', {'title': 'Rechercher', 'type': 'script', 'path': 'script.dark-prophet,recherche',
                                        'thumbnail': icones + 'search.png'})


ACCUEIL_ESTUARY_RETIRE = ('Movie', 'TVShow', 'Music', 'MusicVideo', 'Radio', 'TV', 'Games', 'Pictures', 'Weather')


def formule_extra():
    """Extra-Light : l'habillage d'origine de Kodi (Estuary) avec alkoFlix. Pas de
    pack, pas de profil Catch-up TV, ni vStream, YouTube ou passe-intro : le moins
    possible en mémoire. L'accueil d'Estuary garde « Vidéos », « Extensions » et « Favoris » : les
    catégories d'alkoFlix y sont posées en favoris ; les rubriques de bibliothèque vides en sont retirées."""
    noter_etat_avant()
    if not installer_tout((LANGUE, SONS, SAISIE, ALKOFLIX, FLUX, UPNEXT)):
        return
    franciser()
    regler_confort()
    relier_vstream(False)
    if not changer_habillage(SKIN_ESTUARY):
        dialog.ok(TITRE, "alkoFlix est installé, mais l'habillage n'a pas pu être changé.[CR]Choisis Estuary dans Paramètres > Interface.")
        return
    for nom in ACCUEIL_ESTUARY_RETIRE:
        xbmc.executebuiltin('Skin.SetBool(HomeMenuNo%sButton)' % nom)
    poser_categories_estuary()
    annoncer("C'est installé.[CR]Les catégories d'alkoFlix sont dans « Favoris » de l'accueil, et alkoFlix dans « Extensions ».")


def formule_catchup():
    if not dialog.yesno(TITRE, "Installer Arctic Fuse 3, alkoFlix et Catch-up TV ?[CR]Au démarrage, Kodi proposera deux entrées : « %s » et « %s ».[CR]Kodi passera en français. Les réglages actuels de l'habillage seront remplacés (« Réinitialiser les réglages » les remet)." % (PROFIL_ALKOFLIX, PROFIL_CATCHUP)):
        return
    version = choisir_version(avec_extra=False)
    if not version:
        return
    libre = place_manquante_arctic()
    if libre is not None:
        dialog.ok(TITRE, "Il reste %d Mo libres : Arctic Fuse 3 et ses extensions en demandent environ %d pendant l'installation.[CR]"
                         "Rien n'a été installé. Libère de la place, ou choisis la version Extra-Light dans « Formule alkoFlix »."
                  % (libre, BESOIN_ARCTIC // (1000 * 1000)))
        return
    noter_etat_avant()
    if not installer_tout((LANGUE, SONS, SAISIE, SKIN, ALKOFLIX, ICONES, CATCHUP) + ((VSTREAM, DNS, INTRO) if version == 'full' else ()) + (FLUX, YOUTUBE, UPNEXT)):
        return
    franciser()
    regler_confort()
    pack_alkoflix = telecharger_pack_alkoflix(version)
    pack_catchup = telecharger_pack(PACK_CATCHUP, muet=True) or pack_alkoflix
    relier_alkoflix()
    relier_vstream(version == 'full')
    poser_images_habillage()
    if not appliquer_ici(pack_alkoflix, choisir_fond(), True, version == 'full'):
        dialog.ok(TITRE, "L'habillage n'a pas pu être activé.[CR]Active Arctic Fuse 3 dans Paramètres > Interface, puis relance.")
        return
    preparer_profil_catchup(pack_catchup)


def mettre_a_jour():
    """Pour qui a déjà tout installé : repose la dernière interface publiée
    sur chaque profil et installe ce que les versions récentes ont ajouté
    (icônes, suggestions du clavier, clavier français, YouTube, touche Retour…)."""
    if not dialog.yesno(TITRE, "Mettre l'interface à jour ?[CR]Les réglages actuels de l'habillage seront remplacés par la dernière version (« Réinitialiser les réglages » les remet)."):
        return
    # La question est reposée, partant de la version actuelle : c'est par ici qu'on passe
    # d'une version à l'autre (de la Base à la Full par exemple) sans tout réinstaller.
    version = choisir_version(avec_extra=False)
    if not version:
        return
    if not installer_tout((LANGUE, SONS, SAISIE, ICONES) + ((VSTREAM, DNS, INTRO) if version == 'full' else ()) + (FLUX, YOUTUBE, UPNEXT)):
        return
    franciser()
    regler_confort(dossier_du_profil(PROFIL_CATCHUP) if PROFIL_CATCHUP in profils() else None)
    archive = telecharger_pack_alkoflix(version)
    if archive is None:
        return
    logos = False
    if PROFIL_CATCHUP in profils():
        dossier = dossier_du_profil(PROFIL_CATCHUP)
        copier_extensions_actives(dossier)
        ecrire_pack(telecharger_pack(PACK_CATCHUP, muet=True) or archive, os.path.join(dossier, 'addon_data'))
        ajuster_menu_options(racine=os.path.join(dossier, 'addon_data'))
        fond = telecharger_fond(FOND_CATCHUP)
        if fond:
            poser_fond(fond, os.path.join(dossier, 'addon_data'))
        logos = poser_logos()
    relier_alkoflix()
    relier_vstream(version == 'full')
    poser_images_habillage()
    try:
        actif = appliquer_ici(archive, choisir_fond(redemander=False), PROFIL_CATCHUP in profils(), version == 'full')
    except PackNonApplique as erreur:
        if PROFIL_CATCHUP in profils():
            raise PackNonApplique("%s[CR]Le profil « %s », lui, est déjà à jour : relance la mise à jour pour finir." % (erreur, PROFIL_CATCHUP))
        raise
    if actif:
        if logos:
            annoncer("L'interface est à jour.[CR]Redémarre Kodi : les profils auront leur logo sur l'écran de choix.")
        else:
            annoncer("L'interface est à jour.[CR]Si des menus manquent, redémarre Kodi une fois.")
    else:
        dialog.ok(TITRE, "Réglages copiés, mais l'habillage n'a pas pu être activé.[CR]Active Arctic Fuse 3 dans Paramètres > Interface.")


def ajouter_catchup():
    """Pour qui a pris la formule alkoFlix et change d'avis : ajoute Catch-up TV
    et son profil sans toucher aux réglages du profil ouvert."""
    if not dialog.yesno(TITRE, "Ajouter Catch-up TV ?[CR]Au démarrage, Kodi proposera deux entrées : « %s » et « %s ».[CR]Tes réglages actuels ne sont pas modifiés." % (PROFIL_ALKOFLIX, PROFIL_CATCHUP)):
        return
    if not installer_tout((CATCHUP, FLUX)):
        return
    hors_de_l_habillage(lambda: ajuster_menu_options(True))   # pose aussi le raccourci vers ce script
    preparer_profil_catchup(telecharger_pack(PACK_CATCHUP, muet=True) or telecharger_pack(PACK_ALKOFLIX, muet=True))


def preparer_profil_catchup(pack):
    """Crée le profil Catch-up TV avec son pack, renomme le profil principal et
    active l'écran de choix. Tant que la configuration Catch-up TV n'est pas
    publiée, `pack` est celle d'alkoFlix : même allure, à alléger ensuite."""
    attendre_le_calme()
    if not insister(creer_profil, PROFIL_CATCHUP):
        retour_accueil()
        dialog.ok(TITRE, GUIDE_PROFIL)
        xbmc.executebuiltin('ActivateWindow(profiles)')
        return
    dossier = dossier_du_profil(PROFIL_CATCHUP)
    copier_extensions_actives(dossier)
    choisir_habillage_du_profil(dossier)
    regler_confort(dossier)
    conseil = ''
    if pack is not None:
        try:
            ecrire_pack(pack, os.path.join(dossier, 'addon_data'))
        except PackNonApplique as erreur:
            log('profil Catch-up TV : %s' % erreur)
            conseil = ("[CR]La configuration du profil « %s » n'a pas pu être écrite : ouvre ce profil, "
                       "puis DaRk-PrOphEt > « Remettre la configuration Catch-up TV »." % PROFIL_CATCHUP)
        else:
            ajuster_menu_options(racine=os.path.join(dossier, 'addon_data'))
            fond = telecharger_fond(FOND_CATCHUP)
            if fond:
                poser_fond(fond, os.path.join(dossier, 'addon_data'))

    renomme = insister(renommer_profil_principal, PROFIL_ALKOFLIX)
    ecran = insister(activer_ecran_de_choix)
    retour_accueil()
    poser_logos()   # en dernier : ensuite Kodi ne peut plus enregistrer ses profils jusqu'au redémarrage
    restes = []
    if not renomme:
        restes.append("renommer le profil principal en « %s »" % PROFIL_ALKOFLIX)
    if not ecran:
        restes.append("activer « Afficher l'écran de connexion au démarrage »")
    if restes:
        annoncer("C'est installé. Reste à faire à la main dans Paramètres > Profils :[CR]- " + "[CR]- ".join(restes) + conseil)
    else:
        annoncer("C'est installé.[CR]Redémarre Kodi : tu choisiras entre « %s » et « %s »." % (PROFIL_ALKOFLIX, PROFIL_CATCHUP) + conseil)


def reappliquer_catchup():
    if not dialog.yesno(TITRE, "Remettre la configuration Catch-up TV de DaRk-PrOphEt sur ce profil ?[CR]Les réglages actuels de l'habillage seront remplacés (« Réinitialiser les réglages » les remet)."):
        return
    archive = telecharger_pack(PACK_CATCHUP)
    if archive is None:
        dialog.ok(TITRE, "La configuration Catch-up TV n'est pas encore publiée.")
    elif appliquer_ici(archive, telecharger_fond(FOND_CATCHUP)):
        annoncer("C'est appliqué.[CR]Si des menus manquent, redémarre Kodi une fois.")
    else:
        dialog.ok(TITRE, "Réglages copiés, mais l'habillage n'a pas pu être activé.[CR]Active Arctic Fuse 3 dans Paramètres > Interface.")


# --- Identifiants Catch-up TV -----------------------------------------------

def identifiants_catchup():
    """Les comptes restent dans les réglages de Catch-up TV de CE profil :
    ils ne partent ni dans un pack ni sur le dépôt."""
    if not installe(CATCHUP):
        dialog.ok(TITRE, "Catch-up TV n'est pas installé. Lance d'abord la formule « alkoFlix + Catch-up TV ».")
        return
    if dans_le_profil_principal() and PROFIL_CATCHUP in profils():
        if not dialog.yesno(TITRE, "Les identifiants sont propres à chaque profil.[CR]Ceux saisis ici ne serviront pas dans le profil « %s » : ouvre-le et relance ce menu.[CR]Les saisir quand même ici ?" % PROFIL_CATCHUP):
            return
    catchup = xbmcaddon.Addon(CATCHUP)
    while True:
        lignes = []
        for nom, cle in COMPTES:
            compte = catchup.getSetting(cle + '.login')
            lignes.append('%s : %s' % (nom, compte or 'non renseigné'))
        lignes.append('Saisir depuis mon téléphone…')
        lignes.append('Tous les réglages de Catch-up TV…')
        choix = dialog.select('Mes identifiants Catch-up TV', lignes)
        if choix < 0:
            return
        if choix == len(COMPTES):
            identifiants_par_telephone()
            continue
        if choix == len(COMPTES) + 1:
            catchup.openSettings()
            return
        nom, cle = COMPTES[choix]
        compte = dialog.input('%s : adresse ou identifiant' % nom, catchup.getSetting(cle + '.login'))
        if not compte:
            if catchup.getSetting(cle + '.login') and dialog.yesno(TITRE, 'Effacer le compte %s de cet appareil ?' % nom):
                catchup.setSetting(cle + '.login', '')
                catchup.setSetting(cle + '.password', '')
            continue
        mot_de_passe = dialog.input('%s : mot de passe' % nom, option=xbmcgui.ALPHANUM_HIDE_INPUT)
        if mot_de_passe:
            catchup.setSetting(cle + '.login', compte)
            catchup.setSetting(cle + '.password', mot_de_passe)


# --- Identifiants depuis le téléphone ----------------------------------------

def png(lignes):
    """Image PNG en niveaux de gris à partir de lignes d'octets (0 = noir, 255 = blanc)."""
    def bloc(genre, contenu):
        return struct.pack('>I', len(contenu)) + genre + contenu + struct.pack('>I', zlib.crc32(genre + contenu) & 0xffffffff)
    brut = b''.join(b'\x00' + bytes(ligne) for ligne in lignes)
    return (b'\x89PNG\r\n\x1a\n' + bloc(b'IHDR', struct.pack('>IIBBBBB', len(lignes[0]), len(lignes), 8, 0, 0, 0, 0))
            + bloc(b'IDAT', zlib.compress(brut, 9)) + bloc(b'IEND', b''))


def image_qr(texte, fichier):
    """Écrit le QR code de `texte`. Renvoie False si le module de QR codes manque."""
    try:
        import qrcode
        code = qrcode.QRCode(border=3, error_correction=qrcode.constants.ERROR_CORRECT_M)
        code.add_data(texte)
        code.make(fit=True)
        grille = code.get_matrix()
    except Exception as erreur:   # module absent ou incomplet sur cet appareil : on affichera l'adresse seule
        log('QR code : %r' % erreur)
        return False
    pas = 8
    lignes = []
    for rangee in grille:
        ligne = b''.join((b'\x00' if case else b'\xff') * pas for case in rangee)
        lignes.extend([ligne] * pas)
    with open(fichier, 'wb') as sortie:
        sortie.write(png(lignes))
    return True


PAGE_TELEPHONE = """<!doctype html><html lang="fr"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1"><title>%(titre)s</title>
<style>body{font:17px/1.4 system-ui,sans-serif;margin:0;padding:20px;background:#14131c;color:#f0eef8}
h1{font-size:22px;margin:0 0 6px}p{color:#aaa6bd;margin:0 0 18px}fieldset{border:1px solid #33304a;border-radius:10px;margin:0 0 14px;padding:12px}
legend{font-weight:700;padding:0 6px}label{display:block;font-size:14px;color:#aaa6bd;margin-top:8px}
input{width:100%%;box-sizing:border-box;font:inherit;padding:10px;border-radius:8px;border:1px solid #4a4666;background:#1d1b29;color:inherit}
button{width:100%%;font:inherit;font-weight:700;padding:14px;border:0;border-radius:10px;background:#7b5cf0;color:#fff}
.ok,.non{background:#17402a;border-radius:10px;padding:14px;margin-bottom:18px}.non{background:#4a1d24}</style></head><body>
<h1>%(titre)s</h1><p>%(consigne)s</p>
%(message)s<form method="post">%(champs)s<button type="submit">Enregistrer</button></form></body></html>"""


def identifiants_par_telephone():
    """Les identifiants de replay saisis sur un téléphone : enregistrés dans les
    réglages de Catch-up TV du profil ouvert."""
    catchup = xbmcaddon.Addon(CATCHUP)

    def champs():
        return ''.join('<fieldset><legend>%s</legend><label>Adresse ou identifiant</label>'
                       '<input name="%s.login" value="%s" autocapitalize="none" autocomplete="off">'
                       '<label>Mot de passe</label><input name="%s.password" type="password" autocomplete="off"></fieldset>'
                       % (html.escape(nom), cle, html.escape(catchup.getSetting(cle + '.login'), quote=True), cle)
                       for nom, cle in COMPTES)

    def enregistrer(saisie):
        for _, cle in COMPTES:
            compte = (saisie.get(cle + '.login') or [''])[0].strip()
            mot_de_passe = (saisie.get(cle + '.password') or [''])[0]
            if compte != catchup.getSetting(cle + '.login'):
                catchup.setSetting(cle + '.login', compte)
                if not compte:
                    catchup.setSetting(cle + '.password', '')
            if mot_de_passe:
                catchup.setSetting(cle + '.password', mot_de_passe)
        return True, 'Enregistré. Tu peux fermer cette page et appuyer sur Retour sur Kodi.'

    saisie_par_telephone('Identifiants Catch-up TV',
                         "Ils sont enregistrés sur ton appareil Kodi, nulle part ailleurs. Laisse un mot de passe vide pour garder celui déjà enregistré.",
                         'Saisis tes identifiants, valide, puis appuie sur Retour ici.', champs, enregistrer)


def saisie_par_telephone(titre, consigne, geste, champs, enregistrer):
    """Affiche une adresse (et son QR code) à ouvrir sur un téléphone du même
    réseau : une page y présente champs() et remet la saisie à enregistrer(),
    qui renvoie (réussi, message). Le serveur ne vit que le temps de la
    fenêtre, et son adresse contient un code tiré au hasard."""
    jeton = '%06d' % random.randrange(10 ** 6)

    class Page(BaseHTTPRequestHandler):
        def log_message(self, *arguments):
            pass

        def repondre(self, message=''):
            corps = (PAGE_TELEPHONE % {'titre': html.escape(titre), 'consigne': html.escape(consigne),
                                       'message': message, 'champs': champs()}).encode('utf-8')
            self.send_response(200)
            self.send_header('Content-Type', 'text/html; charset=utf-8')
            self.send_header('Content-Length', str(len(corps)))
            self.end_headers()
            self.wfile.write(corps)

        def autorise(self):
            if self.path.strip('/') == jeton:
                return True
            self.send_error(404)
            return False

        def do_GET(self):
            if self.autorise():
                self.repondre()

        def do_POST(self):
            if not self.autorise():
                return
            saisie = parse_qs(self.rfile.read(int(self.headers.get('Content-Length') or 0)).decode('utf-8'), keep_blank_values=True)
            reussi, message = enregistrer(saisie)
            self.repondre('<div class="%s">%s</div>' % ('ok' if reussi else 'non', html.escape(message)))

    serveur = None
    for port in range(8765, 8771):
        try:
            serveur = HTTPServer(('', port), Page)
            break
        except OSError:
            continue
    if serveur is None:
        dialog.ok(TITRE, "Impossible d'ouvrir la page de saisie sur cet appareil.")
        return
    adresse = 'http://%s:%s/%s' % (xbmc.getIPAddress(), serveur.server_address[1], jeton)
    threading.Thread(target=serveur.serve_forever, daemon=True).start()
    try:
        dossier = os.path.join(ADDON_DATA, 'script.dark-prophet')
        os.makedirs(dossier, exist_ok=True)
        fond, qr = os.path.join(dossier, 'fond-saisie.png'), os.path.join(dossier, 'qr.png')
        with open(fond, 'wb') as sortie:
            sortie.write(png([b'\x12' * 4] * 4))

        class Fenetre(xbmcgui.WindowDialog):
            def onAction(self, action):
                self.close()

        fenetre = Fenetre()
        fenetre.addControl(xbmcgui.ControlImage(0, 0, 1280, 720, fond))
        fenetre.addControl(xbmcgui.ControlLabel(90, 150, 600, 50, titre, textColor='0xFFFFFFFF'))
        zone = xbmcgui.ControlTextBox(90, 220, 600, 320, textColor='0xFFDDDDDD')
        fenetre.addControl(zone)
        zone.setText("Sur un téléphone connecté au même Wi-Fi, ouvre cette adresse%s :[CR][CR][B]%s[/B][CR][CR]"
                     "%s"
                     % (' ou scanne le code' if image_qr(adresse, qr) else '', adresse, geste))
        if os.path.isfile(qr):
            fenetre.addControl(xbmcgui.ControlImage(780, 160, 400, 400, qr))
        fenetre.doModal()
        del fenetre
    finally:
        serveur.shutdown()
        serveur.server_close()
        for fichier in ('qr.png',):
            try:
                os.remove(os.path.join(ADDON_DATA, 'script.dark-prophet', fichier))
            except OSError:
                pass


# --- Lumio (retiré) ----------------------------------------------------------
def retirer_lumio():
    """Défait une seule fois ce que l'entrée « Lumio » des versions 1.16 avait réglé
    dans alkoFlix : Lumio éteint et son lien effacé (il valait un mot de passe), mode
    de recherche par défaut, Comet et la source alkoPaste remis en service. Le témoin
    évite d'y revenir : un Lumio réglé plus tard à la main dans alkoFlix reste intact."""
    # Lumio ne se réglait que dans le profil principal (alkoFlix).
    if os.path.isfile(FICHIER_LUMIO_RETIRE) or not dans_le_profil_principal() or not installe(ALKOFLIX):
        return
    try:
        alkoflix = xbmcaddon.Addon(ALKOFLIX)
        if alkoflix.getSetting('provider.lumio') == 'true' or alkoflix.getSetting('lumio.manifest_url'):
            alkoflix.setSetting('provider.lumio', 'false')
            alkoflix.setSetting('lumio.manifest_url', '')
            alkoflix.setSetting('sources.alkoflix_mode', '0')
            alkoflix.setSetting('provider.comet', 'true')
            alkoflix.setSetting('results.comet_fallback', 'true')
            regler_source_alkopaste(alkoflix, True)
            log('Lumio retiré, alkoFlix remis sur ses propres sources')
        for fichier in (FICHIER_LUMIO, FICHIER_LUMIO_AVANT):
            if os.path.isfile(fichier):
                os.remove(fichier)
        os.makedirs(os.path.dirname(FICHIER_LUMIO_RETIRE), exist_ok=True)
        open(FICHIER_LUMIO_RETIRE, 'w').close()
    except (OSError, RuntimeError) as erreur:
        log('retrait de Lumio : %r' % erreur)


def regler_source_alkopaste(alkoflix, en_service):
    """La SOURCE alkoPaste (les liens), pas son catalogue, qui reste toujours. Coupée
    aussi comme source de secours : sinon alkoFlix retélécharge sa base."""
    alkoflix.setSetting('provider.alkopaste', 'true' if en_service else 'false')
    if en_service:
        return
    alkoflix.setSetting('results.alkopaste_fallback', 'false')
    # alkoFlix n'efface sa base de liens qu'à son prochain entretien : on libère la
    # place tout de suite (mêmes fichiers que lui, journaux et téléchargement en cours compris).
    base = os.path.join(ADDON_DATA, ALKOFLIX, 'alkopaste.db')
    for suffixe in ('', '-journal', '-wal', '-shm', '.download', '.tmp', '.old'):
        try:
            os.remove(base + suffixe)
        except OSError:
            pass


# --- Nettoyage ----------------------------------------------------------------

def vider(dossier, garder=()):
    """Supprime le contenu d'un dossier (pas le dossier). Renvoie les octets libérés."""
    libere = 0
    for chemin, _, fichiers in os.walk(dossier, topdown=False):
        for fichier in fichiers:
            if fichier.endswith(garder):
                continue
            complet = os.path.join(chemin, fichier)
            try:
                taille = os.path.getsize(complet)
                os.remove(complet)
                libere += taille
            except OSError:
                pass   # fichier en cours d'utilisation : on le laisse
        if chemin != dossier:
            try:
                os.rmdir(chemin)
            except OSError:
                pass
    return libere


def nettoyer_paquets(jours=1):
    """Kodi garde le zip de chaque version de chaque extension installée, sans
    jamais rien effacer : sur un boîtier de 8 Go, les mises à jour finissent par
    prendre des centaines de Mo (jusqu'à 60 Mo par version d'Arctic Fuse 3). Ces
    fichiers ne servent plus une fois l'extension installée : on retire ceux de
    plus de `jours` jours, au démarrage, sans rien demander."""
    limite = time.time() - jours * 86400
    for fichier in glob.glob(xbmcvfs.translatePath('special://home/addons/packages/') + '*.zip'):
        try:
            if os.path.getmtime(fichier) < limite:
                os.remove(fichier)
        except OSError as erreur:
            log('paquet gardé %s : %r' % (os.path.basename(fichier), erreur))


def nettoyer():
    """Libère la place prise par ce que Kodi garde sans en avoir besoin : les
    paquets d'installation, les fichiers temporaires et les vignettes de tous
    les profils. Rien de personnel : ni réglages, ni comptes, ni favoris."""
    if not dialog.yesno(TITRE, "Nettoyer Kodi ?[CR]Supprime les paquets d'installation, les fichiers temporaires et les vignettes (elles se refont toutes seules).[CR]Tes réglages et tes comptes ne sont pas touchés. Kodi se fermera à la fin."):
        return
    libere = vider(xbmcvfs.translatePath('special://home/addons/packages/'))
    libere += vider(xbmcvfs.translatePath('special://temp/'), garder=('.log',))
    for profil in [MAITRE] + glob.glob(os.path.join(MAITRE, 'profiles', '*', '')):
        # Kodi tient la liste de ses vignettes dans une base : on ne vide les
        # vignettes que si la base part avec, sinon il afficherait des cases vides.
        try:
            for base in glob.glob(os.path.join(profil, 'Database', 'Textures*.db*')):
                taille = os.path.getsize(base)
                os.remove(base)
                libere += taille
        except OSError as erreur:
            log('vignettes de %s gardées : %r' % (profil, erreur))
            continue
        libere += vider(os.path.join(profil, 'Thumbnails'))
    dialog.ok(TITRE, "%d Mo libérés.[CR]Kodi va se fermer : relance-le. Les images reviendront au fil de la navigation." % round(libere / 1048576))
    xbmc.executebuiltin('Quit')


# --- Réinitialisation -------------------------------

def noter_etat_avant():
    """Relève, une seule fois, les réglages de Kodi que les formules vont changer."""
    if os.path.isfile(ETAT_AVANT):
        return
    etat = {cle: (rpc('Settings.GetSettingValue', {'setting': cle}) or {}).get('value') for cle in REGLAGES_KODI}
    etat['profil'] = (profils() or ['Master user'])[0]
    os.makedirs(os.path.dirname(ETAT_AVANT), exist_ok=True)
    with open(ETAT_AVANT, 'w', encoding='utf-8') as sortie:
        json.dump(etat, sortie)


def reinitialiser():
    """Défait ce que les formules ont mis en place : habillage et réglages
    d'avant, plus de profil Catch-up TV ni d'écran de choix. Les extensions
    restent installées (Kodi n'a pas de commande pour les désinstaller)."""
    avec_catchup = PROFIL_CATCHUP in profils()
    if not dialog.yesno(TITRE, "Revenir à Kodi comme avant l'installation ?[CR]L'habillage et les réglages d'avant sont remis%s.[CR]Les extensions restent installées."
                        % (", le profil « %s » est supprimé avec ses identifiants" % PROFIL_CATCHUP if avec_catchup else '')):
        return
    etat = {}
    if os.path.isfile(ETAT_AVANT):
        try:
            with open(ETAT_AVANT, encoding='utf-8') as source:
                etat = json.load(source)
        except (OSError, ValueError) as erreur:
            log('état d\'avant : %r' % erreur)
    avant = etat.get('lookandfeel.skin') or SKIN_SECOURS
    if avant == SKIN and not os.path.isdir(SAUVEGARDE):
        avant = SKIN_SECOURS
    # 1. On quitte Arctic Fuse 3 (Kodi réécrit les réglages de l'habillage actif en le quittant),
    #    on remet ses réglages d'avant, puis on revient à l'habillage d'avant.
    actif = xbmc.getSkinDir() == SKIN
    if actif and not changer_habillage(SKIN_SECOURS):
        dialog.ok(TITRE, "Impossible de quitter l'habillage. Change-le dans Paramètres > Interface, puis relance.")
        return
    try:
        remettre_sauvegarde()
    except PackNonApplique as erreur:
        # Rien d'autre n'est défait : la sauvegarde, les profils et les réglages de Kodi restent.
        if actif:
            changer_habillage(SKIN)
        dialog.ok(TITRE, "%s[CR]La réinitialisation s'est arrêtée là : relance-la quand le problème est réglé." % erreur)
        return
    changer_habillage(avant)
    # 2. Les réglages de Kodi relevés avant la première installation (absents si elle date d'une ancienne version).
    for cle in REGLAGES_KODI[1:]:
        if cle in etat and etat[cle] is not None:
            if regler(cle, etat[cle]) and cle == 'locale.language':
                xbmc.sleep(4000)
    # 3. Les profils : un seul, sans écran de choix. Même méthode que pour les logos.
    redemarrer = remettre_profil_unique(etat.get('profil') or 'Master user')
    if redemarrer is None:
        # Rien n'est effacé (sauvegarde, état d'avant, profils) : une nouvelle réinitialisation reprendra d'ici.
        annoncer("Les réglages sont remis, mais les profils n'ont pas pu être modifiés.[CR]"
                 "Relance « Réinitialiser les réglages » pour terminer.")
        return
    # 4. Ce que le script avait noté pour lui-même.
    shutil.rmtree(SAUVEGARDE, ignore_errors=True)
    try:
        remplacer_dans_habillage(PLUS_REMPLACEE, PLUS_ORIGINE)
    except OSError as erreur:
        log('image « Plus » : %r' % erreur)
    shutil.rmtree(DOSSIER_IMAGES, ignore_errors=True)
    try:
        os.remove(os.path.join(PROFIL, 'keymaps', NOM_TOUCHES))
        xbmc.executebuiltin('Action(reloadkeymaps)')
    except OSError:
        pass
    images = [os.path.join(DOSSIER_FONDS, fichier) for fichier in [f for _, f in FONDS] + [FOND_CATCHUP, 'fond-saisie.png']]
    for fichier in [ETAT_AVANT, FICHIER_INTERFACE, FICHIER_FOND] + images:
        try:
            os.remove(fichier)
        except OSError:
            pass
    annoncer("C'est réinitialisé.%s" % ("[CR]Redémarre Kodi pour retirer l'écran de choix et le profil « %s »." % PROFIL_CATCHUP if redemarrer else ''))


def remettre_profil_unique(nom):
    """Ne garde que le profil principal, sous son nom d'avant, sans écran de
    choix ni logo. Renvoie True si profiles.xml a changé (redémarrage nécessaire),
    False s'il n'y avait rien à changer, None en cas d'échec."""
    if not os.path.isfile(FICHIER_PROFILS):
        return False   # un seul profil, jamais enregistré : rien à remettre
    try:
        arbre = ElementTree.parse(FICHIER_PROFILS)
        racine = arbre.getroot()
        a_effacer, change = [], False
        for profil in list(racine.iter('profile')):
            if profil.findtext('id') != '0':
                a_effacer.append((profil.findtext('directory') or '').strip('/'))
                racine.remove(profil)
                change = True
                continue
            for balise, valeur in (('name', nom), ('thumbnail', '')):
                element = profil.find(balise)
                if element is not None and (element.text or '') != valeur and (balise != 'thumbnail' or (element.text or '') in LOGOS.values()):
                    element.text = valeur
                    change = True
        for balise, valeur in (('useloginscreen', 'false'), ('lastloaded', '0'), ('autologin', '-1')):
            element = racine.find(balise)
            if element is not None and element.text != valeur:
                element.text = valeur
                change = True
        if not change:
            return False
        os.chmod(FICHIER_PROFILS, 0o644)
        arbre.write(FICHIER_PROFILS, encoding='utf-8')
        os.chmod(FICHIER_PROFILS, 0o444)
        os.makedirs(os.path.dirname(VERROU_PROFILS), exist_ok=True)
        with open(PROFILS_A_EFFACER, 'w', encoding='utf-8') as sortie:
            sortie.write('\n'.join(a_effacer))
        with open(VERROU_PROFILS, 'w') as sortie:
            sortie.write(str(os.getpid()))
        return True
    except (OSError, ElementTree.ParseError) as erreur:
        log('profils : %r' % erreur)
        return None


def rechercher(genre='', sections=''):
    """Recherche par titre limitée au catalogue d'alkoFlix : on ne propose que
    ce qui a des liens. Lancée par les rubriques « Rechercher » des pages :
    RunScript(script.dark-prophet,recherche,<movie|tv>,<sections du catalogue>).
    La recherche par titre d'alkoFlix interroge tout TMDb ; seules ses listes
    « Découvrir » respectent le catalogue, on leur passe donc une recherche
    TMDb. Le filtre par section est celui de « Parce que vous avez regardé »."""
    titres = {'movie': 'Rechercher un film', 'tv': 'Rechercher une série'}
    mot = dialog.input(titres.get(genre, 'Rechercher dans alkoFlix')).strip()
    if not mot:
        return
    cle = xbmcaddon.Addon(ALKOFLIX).getSetting('tmdb_api')

    def tmdb(genre_tmdb):
        # alkoFlix pose le numéro de page avec « adresse % page » : les % du mot
        # tapé (espaces, accents encodés) doivent être doublés, sinon plus d'un mot
        # suffit à faire planter la recherche.
        return ('https://api.themoviedb.org/3/search/' + genre_tmdb + '?api_key=' + cle
                + '&language=fr-FR&page=%s&query=' + quote(mot).replace('%', '%%'))

    nom = quote('Recherche : ' + mot)
    if genre in titres:
        mode, action = (('build_movie_list', 'tmdb_movies_discover') if genre == 'movie'
                        else ('build_tvshow_list', 'tmdb_tv_discover'))
        chemin = 'plugin://%s/?mode=%s&action=%s&catalogue_only=true&name=%s' % (ALKOFLIX, mode, action, nom)
        if sections:
            chemin += '&because_you_watched=true&recommendation_group=all&recommendation_catalogue_section=' + quote(sections)
        chemin += '&query=' + quote(tmdb(genre), safe='')
    else:
        chemin = ('plugin://%s/?mode=discover.combined_results&movie_query=%s&tv_query=%s&name=%s&catalogue_only=true'
                  % (ALKOFLIX, quote(tmdb('movie'), safe=''), quote(tmdb('tv'), safe=''), nom))
    xbmc.executebuiltin('ActivateWindow(Videos,"%s",return)' % chemin)


def oublier_jeton():
    for fichier in RESTES_JETON:
        try:
            os.remove(fichier)
        except OSError:
            pass


def surveiller_listes():
    """Tourne tant que le profil est ouvert. L'habillage ne charge les rangées
    de l'accueil qu'une fois : sans cela, un favori qu'on vient d'ajouter n'y
    apparaît qu'au redémarrage de Kodi. La commande est celle qu'alkoFlix
    emploie lui-même pour recharger les rangées (elle ne touche à aucune
    médiathèque)."""
    def etat():
        return [os.path.getmtime(fichier) if os.path.exists(fichier) else 0 for fichier in TEMOINS_LISTES]

    # Aucune question à l'interface dans cette boucle (getCondVisibility…) : pendant un
    # changement de profil, Kodi la verrouille le temps d'arrêter les services, et un
    # service qui l'interroge à ce moment-là reste bloqué jusqu'à ce que Kodi le coupe,
    # 5 secondes plus tard. Le lecteur se demande sans passer par l'interface.
    moniteur = xbmc.Monitor()
    lecteur = xbmc.Player()
    vu = etat()
    while not moniteur.waitForAbort(3):
        if lecteur.isPlaying():
            continue   # pendant un film, alkoFlix note l'avancement sans arrêt : on attend la fin
        maintenant = etat()
        if maintenant != vu:
            vu = maintenant
            xbmc.executebuiltin('UpdateLibrary(video,special://skin/foo)')
            log('favoris ou listes modifiés : rangées rechargées')


def menu():
    lever_verrou_profils()
    oublier_jeton()
    retirer_lumio()
    reprendre_au_lancement()
    if dans_le_profil_principal():
        entrees = [
            ('Formule alkoFlix', formule_alkoflix),
            ('Formule alkoFlix + Catch-up TV', formule_catchup),
        ]
        if xbmc.getSkinDir() == SKIN and installe(ALKOFLIX):
            # Une formule est déjà en place : on propose d'abord la mise à jour et le complément.
            if PROFIL_CATCHUP not in profils():
                entrees.insert(0, ('Ajouter Catch-up TV à mon installation', ajouter_catchup))
            entrees.insert(0, ("Mettre l'interface à jour", mettre_a_jour))
            entrees.append(("Changer le fond d'écran", changer_fond))
        entrees += [
            ('Mes identifiants Catch-up TV', identifiants_catchup),
            ('Nettoyer Kodi', nettoyer),
            ('Réinitialiser les réglages', reinitialiser),
        ]
    else:
        # La réinitialisation supprime ce profil : elle se lance depuis le profil principal.
        entrees = [
            ('Mes identifiants Catch-up TV', identifiants_catchup),
            ('Remettre la configuration Catch-up TV', reappliquer_catchup),
            ('Nettoyer Kodi', nettoyer),
        ]
    choix = dialog.select(TITRE, [libelle for libelle, _ in entrees])
    if choix >= 0:
        try:
            entrees[choix][1]()
        except PackNonApplique as erreur:
            log('réglages non appliqués : %s' % erreur)
            dialog.ok(TITRE, str(erreur))


if __name__ == '__main__':
    if sys.argv[1:2] == ['recherche']:
        rechercher(*sys.argv[2:4])
    else:
        menu()
